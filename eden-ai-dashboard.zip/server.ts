import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type {
  Agent,
  SwarmRun,
  SwarmAgentResult,
  DAGPipeline,
  DAGNode,
  HostedFile,
  UsageMetric,
} from './src/types/index.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const STORE_PATH = path.join(__dirname, '.nexusflow-store.json');

function getGenAIClient(): GoogleGenAI {
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

interface WorkspaceStore {
  agents: Agent[];
  swarmRuns: SwarmRun[];
  pipelines: DAGPipeline[];
  files: HostedFile[];
  usageLogs: UsageMetric[];
}

const INITIAL_AGENTS: Agent[] = [
  {
    id: 'agent-antigravity',
    name: 'Antigravity Agent',
    role: 'Autonomous Game Engineering & Build Loops',
    avatar: 'AG',
    model: 'gemini-3.8-flash',
    systemInstruction:
      'You are Antigravity, an autonomous agentic game developer. You write engine build loops, state machines, automated playtesting harnesses, and system integrations for Godot, Unity, and Unreal Engine. Focus on modularity, high framerates, and zero-bug runtime invariants.',
    color: '#6366F1',
    connectedTools: ['game_engine_runner', 'github_repo', 'artifact_vault'],
    githubRepo: 'godotengine/godot-demo-projects',
    totalTokens: 64280,
    totalRuns: 48,
    avgLatencyMs: 1140,
    status: 'idle',
  },
  {
    id: 'agent-aistudio',
    name: 'Google AI Studio',
    role: 'Game System Architecture & Tool Integrator',
    avatar: 'GS',
    model: 'gemini-3.8-flash',
    systemInstruction:
      'You are Google AI Studio Assistant, orchestrating multimodal AI pipelines for game studios. You connect APIs, manage webhook callbacks, orchestrate prompt chains, and generate structured schemas for game data, inventory JSON, and save states.',
    color: '#3B82F6',
    connectedTools: ['gemini_api_hub', 'schema_validator', 'artifact_vault'],
    totalTokens: 49120,
    totalRuns: 36,
    avgLatencyMs: 980,
    status: 'idle',
  },
  {
    id: 'agent-gemini',
    name: 'Gemini Game Master',
    role: 'Lore, Worldbuilding & NPC Procedural Dialogue',
    avatar: 'GM',
    model: 'gemini-3.8-flash',
    systemInstruction:
      'You are Gemini Game Master, specializing in deep interactive worldbuilding, procedural NPC dialogue branching, branching lore bibles, faction dynamics, and dynamic quest narrative for RPGs and action adventures.',
    color: '#8B5CF6',
    connectedTools: ['narrative_graph', 'artifact_vault'],
    totalTokens: 58900,
    totalRuns: 42,
    avgLatencyMs: 1020,
    status: 'idle',
  },
  {
    id: 'agent-claude',
    name: 'Claude Engine Specialist',
    role: 'Physics Math, Shaders & C#/C++ Game Mechanics',
    avatar: 'CL',
    model: 'gemini-3.8-flash',
    systemInstruction:
      'You are Claude Engine Specialist. You craft mathematically sound physics controllers, HLSL/GLSL compute shaders, spatial optimization (octrees, BVH), and high-performance C# (Unity) / C++ (Unreal) scripts with strict memory and garbage collection discipline.',
    color: '#D97706',
    connectedTools: ['shader_compiler', 'github_repo', 'artifact_vault'],
    githubRepo: 'Unity-Technologies/PhysicsSamples',
    totalTokens: 71200,
    totalRuns: 55,
    avgLatencyMs: 1250,
    status: 'idle',
  },
  {
    id: 'agent-gpt',
    name: 'GPT Systems & Quest Bot',
    role: 'Combat Balancing, Economy & Quest Graphs',
    avatar: 'GT',
    model: 'gemini-3.8-flash',
    systemInstruction:
      'You are GPT Systems Designer. You simulate RPG progression curves, weapon DPS balancing tables, loot drop probability matrices, skill cooldown trees, and game economy sinks & faucets.',
    color: '#10B981',
    connectedTools: ['economy_simulator', 'artifact_vault'],
    totalTokens: 53400,
    totalRuns: 39,
    avgLatencyMs: 1080,
    status: 'idle',
  },
  {
    id: 'agent-3dmodel',
    name: '3D Modeling Service AI',
    role: 'Meshy / Tripo3D Asset & Texture Pipeline',
    avatar: '3D',
    model: 'gemini-3.1-flash-lite',
    systemInstruction:
      'You are the 3D Modeling AI Asset Pipeline specialist (Meshy / Tripo3D / CSM). You craft clean geometric topology prompts, PBR texture maps (Albedo, Normal, Roughness, Metallic, AO), LOD strategies, and GLTF/OBJ export configurations for game engines.',
    color: '#EC4899',
    connectedTools: ['meshy_api_bridge', 'tripo3d_webhook', 'artifact_vault'],
    webhookUrl: 'https://api.meshy.ai/v2/text-to-3d',
    totalTokens: 38700,
    totalRuns: 31,
    avgLatencyMs: 720,
    status: 'idle',
  },
  {
    id: 'agent-blender',
    name: 'Blender AI Bridge',
    role: 'Automated bpy Scripting, Retopology & Rigging',
    avatar: 'BL',
    model: 'gemini-3.8-flash',
    systemInstruction:
      'You are Blender AI Bridge. You generate production-grade Python (bpy) automation scripts for Blender 4.x: automated quad retopology, auto-seam UV unwrapping, skeletal armature rigging, material node trees, and glTF/FBX batch export pipelines.',
    color: '#F97316',
    connectedTools: ['blender_bpy_runner', 'artifact_vault'],
    totalTokens: 42100,
    totalRuns: 33,
    avgLatencyMs: 890,
    status: 'idle',
  },
  {
    id: 'agent-ue5',
    name: 'UE5 & Visual Studio Bot',
    role: 'Unreal Engine 5 C++, Nanite/Lumen & VS Build Tools',
    avatar: 'U5',
    model: 'gemini-3.8-flash',
    systemInstruction:
      'You are UE5 & Visual Studio Bot. You write optimized Unreal Engine 5.4+ C++ classes (UCLASS, UPROPERTY, UFUNCTION), Gameplay Ability System (GAS) structures, Nanite/Lumen material configurations, and Visual Studio MSBuild / UnrealBuildTool automation scripts.',
    color: '#06B6D4',
    connectedTools: ['ue5_build_bridge', 'visual_studio_compiler', 'github_repo', 'artifact_vault'],
    githubRepo: 'EpicGames/UnrealEngine',
    totalTokens: 68500,
    totalRuns: 47,
    avgLatencyMs: 1290,
    status: 'idle',
  },
];

const INITIAL_PIPELINES: DAGPipeline[] = [
  {
    id: 'pipe-gamedev-full',
    name: '3D Asset to Blender & UE5 Pipeline',
    description:
      'Chains 3D Modeling AI, Blender bpy auto-retopology & rigging, Claude HLSL/GLSL shaders, and UE5 Visual Studio C++ gameplay code into a game-ready character bundle.',
    lastRunAt: '2026-11-07T18:20:00Z',
    lastStatus: 'completed',
    nodes: [
      {
        id: 'node-3d',
        label: '3D Mesh & Texture Generation',
        type: 'agent',
        agentId: 'agent-3dmodel',
        prompt:
          'Generate high-fidelity geometry prompt and PBR texture map specifications for an Ancient Lava Titan boss with 4K albedo, normal, metallic, roughness, and emissive channels.',
        status: 'completed',
        lastOutput:
          'Mesh Specification: Low-poly LOD0 (24,500 quads). Channels: Albedo, Normal, Roughness, Emissive (512nm orange bloom). Ready for Blender import.',
        latencyMs: 720,
        tokens: 420,
        x: 40,
        y: 150,
      },
      {
        id: 'node-blender',
        label: 'Blender bpy Retopology & Rig',
        type: 'agent',
        agentId: 'agent-blender',
        prompt:
          'Generate Blender 4.x Python (bpy) script to import the generated GLTF, perform quad retopology, generate automated UV seams, and bind to human-metarig armature.',
        status: 'completed',
        lastOutput:
          'import bpy\n# Auto-retopologize and rig Titan mesh\nbpy.ops.import_scene.gltf(filepath="titan_raw.gltf")\n# Quad remesh modifier (target: 25k faces)\nremesh = obj.modifiers.new(name="Remesh", type="QUAD_FLOW")\n# Armature binding with automatic weights applied.',
        latencyMs: 910,
        tokens: 610,
        x: 280,
        y: 80,
      },
      {
        id: 'node-claude-shader',
        label: 'Claude HLSL/GLSL Lava Shader',
        type: 'agent',
        agentId: 'agent-claude',
        prompt:
          'Write an optimized HLSL/GLSL vertex & pixel shader with dynamic Voronoi crust displacement and molten flow distortion for Unreal Engine 5.',
        status: 'completed',
        lastOutput:
          '// HLSL Lava Crust Shader for UE5 Custom Material Node\nfloat3 flow = tex2D(FlowMap, UV + _Time.y * 0.05).rgb;\nfloat crust = saturate(Voronoi(UV * 8.0) - Heat);\nfloat3 color = lerp(MoltenColor * 1.8, RockCrust, crust);',
        latencyMs: 1180,
        tokens: 780,
        x: 280,
        y: 220,
      },
      {
        id: 'node-ue5-cpp',
        label: 'UE5 C++ Character Controller',
        type: 'agent',
        agentId: 'agent-ue5',
        prompt:
          'Generate Unreal Engine 5.4 C++ class ABossTitanCharacter inheriting from ACharacter, configuring Nanite meshes, Lumen emissive lighting, and Gameplay Ability System (GAS) abilities.',
        status: 'completed',
        lastOutput:
          '#pragma once\n#include "CoreMinimal.h"\n#include "GameFramework/Character.h"\n#include "AbilitySystemInterface.h"\n#include "BossTitanCharacter.generated.h"\n\nUCLASS(config=Game)\nclass ABossTitanCharacter : public ACharacter, public IAbilitySystemInterface {\n  GENERATED_BODY()\npublic:\n  UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Abilities")\n  UAbilitySystemComponent* AbilitySystemComponent;\n};',
        latencyMs: 1310,
        tokens: 950,
        x: 560,
        y: 150,
      },
      {
        id: 'node-antigravity-verify',
        label: 'Antigravity Build Loop & Test',
        type: 'agent',
        agentId: 'agent-antigravity',
        prompt:
          'Run autonomous build verification loop across generated Blender script, shader, and UE5 C++ class to verify zero invariant violations.',
        status: 'completed',
        lastOutput:
          'Antigravity Invariant Check: PASSED.\n- Blender bpy syntax: 0 errors\n- Shader instructions: 48 ALUs (within budget)\n- UE5 C++ MSBuild: Compiled with 0 warnings\n- GC Invariants: 0 allocations in tick loop',
        latencyMs: 1040,
        tokens: 520,
        x: 820,
        y: 150,
      },
      {
        id: 'node-save-bundle',
        label: 'Host in Game Vault',
        type: 'artifact_save',
        outputPath: '/artifacts/ue5_boss_titan_bundle.md',
        status: 'completed',
        lastOutput: 'Saved 3,840 bytes to /artifacts/ue5_boss_titan_bundle.md',
        latencyMs: 35,
        tokens: 0,
        x: 1060,
        y: 150,
      },
    ],
    edges: [
      { id: 'eg-1', source: 'node-3d', target: 'node-blender' },
      { id: 'eg-2', source: 'node-3d', target: 'node-claude-shader' },
      { id: 'eg-3', source: 'node-blender', target: 'node-ue5-cpp' },
      { id: 'eg-4', source: 'node-claude-shader', target: 'node-ue5-cpp' },
      { id: 'eg-5', source: 'node-ue5-cpp', target: 'node-antigravity-verify' },
      { id: 'eg-6', source: 'node-antigravity-verify', target: 'node-save-bundle' },
    ],
  },
  {
    id: 'pipe-pr-audit',
    name: 'GitHub Repo Audit & Patch Synthesis',
    description:
      'Fetches repository context from GitHub, runs Architecture and Security agents in parallel, synthesizes a hardened patch specification, and commits the artifact to the vault.',
    lastRunAt: '2026-11-07T17:15:00Z',
    lastStatus: 'completed',
    nodes: [
      {
        id: 'node-1',
        label: 'GitHub Context Ingest',
        type: 'github_fetch',
        repoTarget: 'modelcontextprotocol/servers',
        status: 'completed',
        lastOutput:
          'Fetched repository modelcontextprotocol/servers (branch: main). Located core TypeScript SDK interfaces and server transport adapters.',
        latencyMs: 420,
        tokens: 0,
        x: 60,
        y: 150,
      },
      {
        id: 'node-2',
        label: 'Architecture Review',
        type: 'agent',
        agentId: 'agent-architect',
        prompt:
          'Analyze the ingested repository context and identify 3 key architectural improvements for high-concurrency multi-agent tool calls.',
        status: 'completed',
        lastOutput:
          '1. Introduce connection multiplexing over SSE/Stdio transports.\n2. Add bounded backpressure queues per tool invocation.\n3. Implement idempotent request correlation IDs across agent hops.',
        latencyMs: 1140,
        tokens: 680,
        x: 340,
        y: 60,
      },
      {
        id: 'node-3',
        label: 'Security Threat Scan',
        type: 'agent',
        agentId: 'agent-secops',
        prompt:
          'Audit the ingested repository context for capability escalation, SSRF in webhook tools, and token validation gaps.',
        status: 'completed',
        lastOutput:
          '1. Enforce strict allowlists on outbound webhook URLs to prevent SSRF.\n2. Scope tool execution tokens per session.\n3. Sanitize JSON-RPC error payloads before returning to untrusted callers.',
        latencyMs: 1090,
        tokens: 640,
        x: 340,
        y: 240,
      },
      {
        id: 'node-4',
        label: 'Patch & Spec Synthesis',
        type: 'agent',
        agentId: 'agent-synthesizer',
        prompt:
          'Combine the Architecture Review and Security Threat Scan into a unified implementation checklist and release readiness report.',
        status: 'completed',
        lastOutput:
          '# Unified Release Hardening Plan\n\n- **Transport Layer**: Multiplexed SSE with correlation IDs\n- **Security Boundary**: Outbound SSRF allowlist + scoped session tokens\n- **Verification**: Automated regression suite added to CI pipeline.',
        latencyMs: 1210,
        tokens: 890,
        x: 640,
        y: 150,
      },
      {
        id: 'node-5',
        label: 'Publish to Artifact Vault',
        type: 'artifact_save',
        outputPath: '/artifacts/mcp-hardening-report.md',
        status: 'completed',
        lastOutput: 'Saved 1,420 bytes to /artifacts/mcp-hardening-report.md',
        latencyMs: 45,
        tokens: 0,
        x: 920,
        y: 150,
      },
    ],
    edges: [
      { id: 'e1-2', source: 'node-1', target: 'node-2' },
      { id: 'e1-3', source: 'node-1', target: 'node-3' },
      { id: 'e2-4', source: 'node-2', target: 'node-4' },
      { id: 'e3-4', source: 'node-3', target: 'node-4' },
      { id: 'e4-5', source: 'node-4', target: 'node-5' },
    ],
  },
  {
    id: 'pipe-api-codegen',
    name: 'Parallel API Spec to Full-Stack Bundle',
    description:
      'Coordinates Vanguard Coder and Pulse DevOps in parallel to generate a TypeScript API router, CI workflow, and webhook notification.',
    lastRunAt: '2026-11-07T16:40:00Z',
    lastStatus: 'completed',
    nodes: [
      {
        id: 'n2-1',
        label: 'API Contract Architect',
        type: 'agent',
        agentId: 'agent-architect',
        prompt:
          'Define a clean REST + SSE API contract for a multi-agent task queue with webhook callbacks and rate-limit headers.',
        status: 'idle',
        x: 60,
        y: 150,
      },
      {
        id: 'n2-2',
        label: 'TypeScript Handler Codegen',
        type: 'agent',
        agentId: 'agent-codegen',
        prompt:
          'Generate the Express TypeScript route implementation and Zod validation schema for the upstream API contract.',
        status: 'idle',
        x: 360,
        y: 70,
      },
      {
        id: 'n2-3',
        label: 'GitHub Actions CI Generator',
        type: 'agent',
        agentId: 'agent-devops',
        prompt:
          'Create a GitHub Actions workflow YAML that lints, tests, and deploys the generated API service on push to main.',
        status: 'idle',
        x: 360,
        y: 230,
      },
      {
        id: 'n2-4',
        label: 'Save Bundle to Vault',
        type: 'artifact_save',
        outputPath: '/artifacts/api-service-bundle.md',
        status: 'idle',
        x: 680,
        y: 150,
      },
    ],
    edges: [
      { id: 'e2-1-2', source: 'n2-1', target: 'n2-2' },
      { id: 'e2-1-3', source: 'n2-1', target: 'n2-3' },
      { id: 'e2-2-4', source: 'n2-2', target: 'n2-4' },
      { id: 'e2-3-4', source: 'n2-3', target: 'n2-4' },
    ],
  },
];

const INITIAL_FILES: HostedFile[] = [
  {
    id: 'file-1',
    path: '/artifacts/mcp-hardening-report.md',
    name: 'mcp-hardening-report.md',
    category: 'pipeline_artifact',
    language: 'markdown',
    sizeBytes: 1482,
    authorAgentName: 'Nexus Coordinator',
    githubRef: 'modelcontextprotocol/servers@main',
    updatedAt: '2026-11-07T17:15:12Z',
    content: `# MCP Server Transport & Security Hardening Report

Generated by **NexusFlow DAG Pipeline**: \`GitHub Repo Audit & Patch Synthesis\`
Target Repository: \`modelcontextprotocol/servers\`

## 1. Executive Summary
Parallel evaluation by **Atlas Architect** and **Sentinel SecOps** identified three high-leverage transport optimizations and three security boundary controls required before production deployment.

## 2. Architectural Recommendations (Atlas Architect)
- **Multiplexed SSE Streams**: Consolidate concurrent agent tool invocations over a single keep-alive channel with strict \`X-Correlation-ID\` headers.
- **Backpressure Control**: Bound per-agent in-flight tool queues to 32 concurrent requests to prevent memory exhaustion during swarm bursts.
- **Deterministic Retry Policy**: Apply exponential backoff with jitter on HTTP 429/503 upstream tool responses.

## 3. Security Remediation Checklist (Sentinel SecOps)
- **Outbound Webhook SSRF Guard**: Reject RFC1918 private subnets (\`10.0.0.0/8\`, \`127.0.0.1/8\`, \`169.254.169.254\`) in dynamic webhook connectors.
- **Scoped Ephemeral Tokens**: Bind tool execution permissions to the active pipeline run ID.
- **Structured Error Redaction**: Strip stack traces and environment variables from serialized agent error responses.
`,
  },
  {
    id: 'file-2',
    path: '/workflows/swarm-orchestrator-config.json',
    name: 'swarm-orchestrator-config.json',
    category: 'agent_scratchpad',
    language: 'json',
    sizeBytes: 964,
    authorAgentName: 'Pulse DevOps',
    githubRef: 'local/workspace',
    updatedAt: '2026-11-07T16:50:00Z',
    content: JSON.stringify(
      {
        version: '2.4.0',
        orchestrationMode: 'parallel-swarm-dag',
        defaultCoordinator: 'agent-synthesizer',
        concurrencyLimit: 5,
        retryPolicy: {
          maxAttempts: 3,
          backoffMs: 500,
        },
        integrations: {
          github: {
            enabled: true,
            defaultBranch: 'main',
            autoSyncArtifacts: true,
          },
          webhooks: {
            timeoutMs: 8000,
            verifyTls: true,
          },
        },
      },
      null,
      2
    ),
  },
  {
    id: 'file-3',
    path: '/github/modelcontextprotocol/README.md',
    name: 'README.md',
    category: 'github_repo',
    language: 'markdown',
    sizeBytes: 1120,
    authorAgentName: 'GitHub Sync',
    githubRef: 'modelcontextprotocol/servers@HEAD',
    updatedAt: '2026-11-07T16:10:00Z',
    content: `# Model Context Protocol (MCP) Reference Servers

Synced via **NexusFlow GitHub Connector** from \`modelcontextprotocol/servers\`.

## Overview
This repository hosts reference implementations of Model Context Protocol servers that give AI agents controlled, auditable access to external tools, repositories, file systems, and APIs.

## Connected NexusFlow Agents
- **Atlas Architect**: Reviews transport schemas and tool definitions
- **Sentinel SecOps**: Audits sandboxing and permission boundaries
- **Vanguard Coder**: Generates TypeScript tool handlers and test suites
`,
  },
  {
    id: 'file-4',
    path: '/src/pipelines/webhook-dispatcher.ts',
    name: 'webhook-dispatcher.ts',
    category: 'user_upload',
    language: 'typescript',
    sizeBytes: 1045,
    authorAgentName: 'Vanguard Coder',
    githubRef: 'local/workspace',
    updatedAt: '2026-11-07T15:30:00Z',
    content: `export interface WebhookPayload {
  eventId: string;
  pipelineId: string;
  timestamp: string;
  agentsInvolved: string[];
  artifactPath?: string;
  summary: string;
}

export async function dispatchAgentWebhook(
  endpointUrl: string,
  payload: WebhookPayload
): Promise<{ status: number; ok: boolean; durationMs: number }> {
  const start = performance.now();
  const response = await fetch(endpointUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-NexusFlow-Event': 'pipeline.completed',
    },
    body: JSON.stringify(payload),
  });

  return {
    status: response.status,
    ok: response.ok,
    durationMs: Math.round(performance.now() - start),
  };
}
`,
  },
];

const INITIAL_SWARM_RUNS: SwarmRun[] = [
  {
    id: 'swarm-seed-1',
    prompt:
      'Design a zero-downtime webhook ingestion pipeline that fans out GitHub push events to 3 specialized AI review agents and stores the merged diff report.',
    timestamp: '2026-11-07T17:30:00Z',
    agentIds: ['agent-architect', 'agent-secops', 'agent-devops'],
    savedArtifactPath: '/artifacts/mcp-hardening-report.md',
    synthesis:
      '### Consensus Architecture Summary\n\n1. **Ingestion Edge**: Verify `X-Hub-Signature-256` HMAC at the Express gateway before enqueueing events.\n2. **Parallel Fan-Out**: Dispatch the commit diff payload concurrently to **Atlas Architect**, **Sentinel SecOps**, and **Pulse DevOps** using `Promise.allSettled` with a 15s deadline.\n3. **Artifact Persistence**: Write the synthesized Markdown review directly into `/artifacts/` with the commit SHA reference.',
    results: [
      {
        agentId: 'agent-architect',
        agentName: 'Atlas Architect',
        agentRole: 'Systems & Distributed Architecture',
        color: 'indigo',
        latencyMs: 1120,
        tokens: 540,
        status: 'completed',
        content:
          '### Architectural Topology\n- Decouple GitHub webhook ingestion from agent execution using an asynchronous job buffer.\n- Fan out commit diffs to parallel worker lanes keyed by `repository + commit_sha` for idempotency.\n- Aggregate responses via a barrier coordinator that writes a versioned artifact.',
      },
      {
        agentId: 'agent-secops',
        agentName: 'Sentinel SecOps',
        agentRole: 'Security Audit & Threat Modeling',
        color: 'emerald',
        latencyMs: 980,
        tokens: 490,
        status: 'completed',
        content:
          '### Security Controls\n- Validate `X-Hub-Signature-256` using constant-time comparison (`crypto.timingSafeEqual`).\n- Strip untrusted prompt-injection markers from commit messages before passing to downstream LLM contexts.\n- Enforce read-only repository scopes on ingestion tokens.',
      },
      {
        agentId: 'agent-devops',
        agentName: 'Pulse DevOps',
        agentRole: 'CI/CD Pipelines & Webhook Integrator',
        color: 'amber',
        latencyMs: 640,
        tokens: 410,
        status: 'completed',
        content:
          '### CI/CD & Observability\n- Emit structured telemetry (`latency_ms`, `tokens_used`, `agent_id`) per fan-out lane.\n- Automatically post a status check back to the GitHub Pull Request with a direct link to the hosted artifact.',
      },
    ],
  },
];

const INITIAL_USAGE_LOGS: UsageMetric[] = [
  {
    id: 'log-1',
    timestamp: '2026-11-07T17:30:04Z',
    agentId: 'agent-architect',
    agentName: 'Atlas Architect',
    operation: 'Swarm Broadcast',
    tokens: 540,
    latencyMs: 1120,
    status: 'success',
  },
  {
    id: 'log-2',
    timestamp: '2026-11-07T17:30:04Z',
    agentId: 'agent-secops',
    agentName: 'Sentinel SecOps',
    operation: 'Swarm Broadcast',
    tokens: 490,
    latencyMs: 980,
    status: 'success',
  },
  {
    id: 'log-3',
    timestamp: '2026-11-07T17:30:03Z',
    agentId: 'agent-devops',
    agentName: 'Pulse DevOps',
    operation: 'Swarm Broadcast',
    tokens: 410,
    latencyMs: 640,
    status: 'success',
  },
  {
    id: 'log-4',
    timestamp: '2026-11-07T17:15:10Z',
    agentId: 'agent-synthesizer',
    agentName: 'Nexus Coordinator',
    operation: 'DAG Step',
    tokens: 890,
    latencyMs: 1210,
    status: 'success',
  },
  {
    id: 'log-5',
    timestamp: '2026-11-07T17:15:08Z',
    agentId: 'agent-secops',
    agentName: 'Sentinel SecOps',
    operation: 'DAG Step',
    tokens: 640,
    latencyMs: 1090,
    status: 'success',
  },
  {
    id: 'log-6',
    timestamp: '2026-11-07T17:15:08Z',
    agentId: 'agent-architect',
    agentName: 'Atlas Architect',
    operation: 'DAG Step',
    tokens: 680,
    latencyMs: 1140,
    status: 'success',
  },
];

function loadStore(): WorkspaceStore {
  try {
    if (fs.existsSync(STORE_PATH)) {
      const raw = fs.readFileSync(STORE_PATH, 'utf-8');
      const loaded = JSON.parse(raw) as WorkspaceStore;
      // Merge in new Game Dev AI agents if not already present
      for (const initAgent of INITIAL_AGENTS) {
        if (!loaded.agents.some((a) => a.id === initAgent.id)) {
          loaded.agents.push(initAgent);
        }
      }
      for (const initPipe of INITIAL_PIPELINES) {
        if (!loaded.pipelines.some((p) => p.id === initPipe.id)) {
          loaded.pipelines.unshift(initPipe);
        }
      }
      return loaded;
    }
  } catch (err) {
    console.error('Failed to read store, using defaults:', err);
  }
  const initial: WorkspaceStore = {
    agents: INITIAL_AGENTS,
    swarmRuns: INITIAL_SWARM_RUNS,
    pipelines: INITIAL_PIPELINES,
    files: INITIAL_FILES,
    usageLogs: INITIAL_USAGE_LOGS,
  };
  saveStore(initial);
  return initial;
}

function saveStore(store: WorkspaceStore) {
  try {
    fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write store:', err);
  }
}

let store = loadStore();

function estimateTokens(text: string): number {
  return Math.max(32, Math.ceil(text.length / 3.6));
}

async function runSingleAgent(
  agent: Agent,
  userPrompt: string,
  extraContext?: string
): Promise<{ text: string; latencyMs: number; tokens: number }> {
  const start = Date.now();
  const ai = getGenAIClient();

  const fullContents = extraContext
    ? `Context / Upstream Data:\n${extraContext}\n\nTask / Command:\n${userPrompt}`
    : userPrompt;

  const response = await ai.models.generateContent({
    model: agent.model || 'gemini-3.8-flash',
    contents: fullContents,
    config: {
      systemInstruction: `${agent.systemInstruction}\nKeep your response well-structured, concise, and immediately useful in a developer command center.`,
    },
  });

  const outputText = response.text ?? 'No output returned by model.';
  const latencyMs = Math.max(120, Date.now() - start);
  const tokens =
    response.usageMetadata?.totalTokenCount ||
    estimateTokens(fullContents + outputText);

  return { text: outputText, latencyMs, tokens };
}

async function fetchGitHubRepoSummary(repoTarget: string): Promise<{
  summary: string;
  filesImported: HostedFile[];
}> {
  const cleanRepo = repoTarget
    .trim()
    .replace(/^https?:\/\/github\.com\//i, '')
    .replace(/\/+$/, '');

  const headers: Record<string, string> = {
    Accept: 'application/vnd.github.v3+json',
    'User-Agent': 'NexusFlow-AI-Workstation',
  };

  const repoRes = await fetch(`https://api.github.com/repos/${cleanRepo}`, {
    headers,
  });

  if (!repoRes.ok) {
    throw new Error(
      `GitHub API returned ${repoRes.status} for repository "${cleanRepo}". Ensure it is a valid public owner/repo path.`
    );
  }

  const repoData = (await repoRes.json()) as {
    full_name: string;
    description: string;
    default_branch: string;
    stargazers_count: number;
    language: string;
    updated_at: string;
  };

  const importedFiles: HostedFile[] = [];

  // Fetch README if available
  try {
    const readmeRes = await fetch(
      `https://api.github.com/repos/${cleanRepo}/readme`,
      { headers }
    );
    if (readmeRes.ok) {
      const readmeJson = (await readmeRes.json()) as {
        name: string;
        content?: string;
        encoding?: string;
      };
      if (readmeJson.content && readmeJson.encoding === 'base64') {
        const decoded = Buffer.from(readmeJson.content, 'base64')
          .toString('utf-8')
          .slice(0, 12000);
        importedFiles.push({
          id: `gh-${Date.now()}-readme`,
          path: `/github/${cleanRepo}/${readmeJson.name}`,
          name: readmeJson.name,
          category: 'github_repo',
          language: 'markdown',
          sizeBytes: Buffer.byteLength(decoded, 'utf-8'),
          content: decoded,
          authorAgentName: 'GitHub Sync',
          githubRef: `${cleanRepo}@${repoData.default_branch}`,
          updatedAt: new Date().toISOString(),
        });
      }
    }
  } catch {
    // Ignore optional README errors
  }

  // Fetch root directory listing
  let treeSummary = '';
  try {
    const contentsRes = await fetch(
      `https://api.github.com/repos/${cleanRepo}/contents`,
      { headers }
    );
    if (contentsRes.ok) {
      const items = (await contentsRes.json()) as Array<{
        name: string;
        path: string;
        type: string;
        size: number;
      }>;
      if (Array.isArray(items)) {
        treeSummary = items
          .slice(0, 25)
          .map((item) => `- [${item.type}] ${item.path} (${item.size} B)`)
          .join('\n');

        const manifestContent = JSON.stringify(
          {
            repository: repoData.full_name,
            description: repoData.description,
            defaultBranch: repoData.default_branch,
            stars: repoData.stargazers_count,
            primaryLanguage: repoData.language,
            syncedAt: new Date().toISOString(),
            rootEntries: items.slice(0, 30).map((i) => ({
              name: i.name,
              type: i.type,
              size: i.size,
            })),
          },
          null,
          2
        );

        importedFiles.push({
          id: `gh-${Date.now()}-manifest`,
          path: `/github/${cleanRepo}/repo-tree.json`,
          name: 'repo-tree.json',
          category: 'github_repo',
          language: 'json',
          sizeBytes: Buffer.byteLength(manifestContent, 'utf-8'),
          content: manifestContent,
          authorAgentName: 'GitHub Sync',
          githubRef: `${cleanRepo}@${repoData.default_branch}`,
          updatedAt: new Date().toISOString(),
        });
      }
    }
  } catch {
    // Ignore optional tree listing error
  }

  const summary = `Repository: ${repoData.full_name} (Branch: ${repoData.default_branch}, Language: ${repoData.language || 'Polyglot'}, Stars: ${repoData.stargazers_count})\nDescription: ${repoData.description || 'No description'}\nRoot Entries:\n${treeSummary || 'Standard repository structure'}`;

  return { summary, filesImported: importedFiles };
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '5mb' }));

  // 1. Get complete workspace state
  app.get('/api/workspace', (_req, res) => {
    const totalTokens = store.agents.reduce((acc, a) => acc + a.totalTokens, 0);
    const totalRuns = store.agents.reduce((acc, a) => acc + a.totalRuns, 0);
    const avgLatencyMs =
      store.agents.length > 0
        ? Math.round(
            store.agents.reduce((acc, a) => acc + a.avgLatencyMs, 0) /
              store.agents.length
          )
        : 0;

    res.json({
      agents: store.agents,
      swarmRuns: store.swarmRuns,
      pipelines: store.pipelines,
      files: store.files,
      telemetry: {
        totalTokens,
        totalRuns,
        avgLatencyMs,
        activeAgentsCount: store.agents.filter((a) => a.status !== 'offline')
          .length,
        estimatedCost: Number(((totalTokens / 1_000_000) * 0.35).toFixed(4)),
        recentLogs: store.usageLogs.slice(0, 40),
      },
    });
  });

  app.get('/api/agents', (_req, res) => {
    res.json({ agents: store.agents });
  });

  app.get('/api/usage', (_req, res) => {
    const totalTokens = store.agents.reduce((acc, a) => acc + a.totalTokens, 0);
    const totalRuns = store.agents.reduce((acc, a) => acc + a.totalRuns, 0);
    const avgLatencyMs =
      store.agents.length > 0
        ? Math.round(
            store.agents.reduce((acc, a) => acc + a.avgLatencyMs, 0) /
              store.agents.length
          )
        : 0;

    res.json({
      totalTokens,
      totalRuns,
      avgLatencyMs,
      activeAgentsCount: store.agents.filter((a) => a.status !== 'offline').length,
      estimatedCost: Number(((totalTokens / 1_000_000) * 0.35).toFixed(4)),
      recentLogs: store.usageLogs.slice(0, 50),
    });
  });

  app.post('/api/usage/grill', async (req, res) => {
    const { userDefense } = req.body || {};
    const totalTokens = store.agents.reduce((acc, a) => acc + a.totalTokens, 0);
    const totalRuns = store.agents.reduce((acc, a) => acc + a.totalRuns, 0);
    const sortedByTokens = [...store.agents].sort((a, b) => b.totalTokens - a.totalTokens);
    const agentBreakdown = sortedByTokens
      .map(
        (a) =>
          `- ${a.name} (${a.role}) [${a.model}]: ${a.totalTokens.toLocaleString()} tokens across ${a.totalRuns} runs (${Math.round((a.totalTokens / (totalTokens || 1)) * 100)}% share, ${a.avgLatencyMs}ms avg latency)`
      )
      .join('\n');

    try {
      const ai = getGenAIClient();
      const prompt = `Here is the developer's current Game Dev AI Fleet telemetry:
Total Tokens Burned: ${totalTokens.toLocaleString()} / 500,000 monthly quota (${Math.round((totalTokens / 500000) * 100)}%)
Total Swarm & Pipeline Runs: ${totalRuns}
Hosted Artifacts in Vault: ${store.files.length}

Agent-by-Agent Breakdown:
${agentBreakdown}

${userDefense ? `Developer's response / defense: "${userDefense}"\n` : ''}
Task:
1. Give a sharp, candid, no-fluff "Usage Audit & Grill" of how they are spending their AI tokens across Antigravity, Google AI Studio, Gemini, Claude, GPT, 3D Modeling AI, Blender, and UE5/Visual Studio.
2. Call out specific imbalances (e.g., heavy C++/Shader token burn on Claude & UE5 vs. under-utilizing 3D Modeling AI & Blender bpy automation on Flash-Lite, or running 8-agent broadcasts when 3 targeted agents would cut latency by 40%).
3. Ask 3 tough, pointed "Grill Questions" about their current game dev bottleneck (e.g., greybox playable loop vs. premature shader/lore polish, asset pipeline automation, and token ROI).
4. Give 3 concrete next commands to fix the imbalance immediately.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction:
            'You are the Lead Technical Producer & AI Usage Auditor for a game studio. You are direct, insightful, witty, and constructively ruthless about token ROI, playable frame rates, and shipping games instead of burning tokens on scope creep.',
        },
      });

      res.json({
        grillReport: response.text || 'Audit complete.',
        totalTokens,
        totalRuns,
        quotaPercent: Math.min(100, Math.round((totalTokens / 500000) * 100)),
        topConsumer: sortedByTokens[0]?.name || 'Claude Engine Specialist',
        lowestConsumer: sortedByTokens[sortedByTokens.length - 1]?.name || 'Pulse DevOps',
      });
    } catch (err: any) {
      res.status(500).json({
        error: err?.message || 'Failed to generate usage grill report.',
      });
    }
  });

  app.get('/api/pipelines', (_req, res) => {
    res.json({ pipelines: store.pipelines });
  });

  app.get('/api/files', (_req, res) => {
    res.json({ files: store.files });
  });

  app.put('/api/files/:id', (req, res) => {
    const file = store.files.find((f) => f.id === req.params.id);
    if (!file) {
      res.status(404).json({ error: 'File not found' });
      return;
    }
    const { content, path: newPath, language } = req.body;
    if (content !== undefined) {
      file.content = content;
      file.sizeBytes = Buffer.byteLength(content, 'utf-8');
    }
    if (newPath) file.path = newPath;
    if (language) file.language = language;
    file.updatedAt = new Date().toISOString();
    saveStore(store);
    res.json({ file });
  });

  app.post('/api/swarm/synthesize', async (req, res) => {
    const { prompt, results } = req.body;
    if (!prompt || !Array.isArray(results) || results.length === 0) {
      res.status(400).json({ error: 'Prompt and results array required' });
      return;
    }
    try {
      const ai = getGenAIClient();
      const agentSummaries = results
        .map((r: any) => `Agent [${r.agentName || r.agentId}]:\n${r.content}`)
        .join('\n\n---\n\n');
      const synthPrompt = `Synthesize the following parallel agent findings for prompt: "${prompt}"\n\n${agentSummaries}\n\nProduce an executive unified consensus recommendation with code if appropriate.`;
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: synthPrompt,
        config: {
          systemInstruction: 'You are Nexus Master Coordinator, synthesizing multi-agent findings into a clear, decisive action plan.',
        },
      });
      res.json({ synthesis: response.text || 'Synthesis complete.' });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Synthesis failed' });
    }
  });

  app.post('/api/github/fetch-repo', async (req, res) => {
    const { repo, filePath } = req.body;
    if (!repo) {
      res.status(400).json({ error: 'Repository name required (e.g. owner/repo)' });
      return;
    }
    try {
      const headers = { 'User-Agent': 'NexusFlow-AI-Workstation' };
      const url = filePath
        ? `https://api.github.com/repos/${repo}/contents/${filePath}`
        : `https://api.github.com/repos/${repo}/contents`;
      const ghRes = await fetch(url, { headers });
      if (!ghRes.ok) {
        res.status(ghRes.status).json({ error: `GitHub API returned ${ghRes.status}` });
        return;
      }
      const data: any = await ghRes.json();
      if (Array.isArray(data)) {
        res.json({
          type: 'dir',
          items: data.map((item: any) => ({
            name: item.name,
            path: item.path,
            type: item.type,
            size: item.size,
          })),
        });
      } else if (data.content && data.encoding === 'base64') {
        const decoded = Buffer.from(data.content, 'base64').toString('utf-8');
        const newFile: HostedFile = {
          id: `gh-${Date.now()}`,
          path: `/github/${repo}/${data.path}`,
          name: data.name,
          category: 'github_repo',
          language: data.name.endsWith('.ts') ? 'typescript' : data.name.endsWith('.json') ? 'json' : 'markdown',
          sizeBytes: data.size,
          content: decoded,
          authorAgentName: 'GitHub Sync',
          githubRef: `${repo}@main`,
          updatedAt: new Date().toISOString(),
        };
        store.files.unshift(newFile);
        saveStore(store);
        res.json({ type: 'file', file: newFile });
      } else {
        res.json({ data });
      }
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Failed to fetch from GitHub' });
    }
  });

  // 2. Create or update an agent
  app.post('/api/agents', (req, res) => {
    const payload = req.body as Partial<Agent>;
    if (!payload.name || !payload.role || !payload.systemInstruction) {
      res
        .status(400)
        .json({ error: 'Name, role, and systemInstruction are required.' });
      return;
    }

    const existingIdx = store.agents.findIndex((a) => a.id === payload.id);
    if (existingIdx >= 0) {
      store.agents[existingIdx] = {
        ...store.agents[existingIdx],
        ...payload,
      };
      saveStore(store);
      res.json({ agent: store.agents[existingIdx] });
      return;
    }

    const initials = payload.name
      .split(' ')
      .map((w) => w[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);

    const newAgent: Agent = {
      id: `agent-${Date.now()}`,
      name: payload.name,
      role: payload.role,
      avatar: initials || 'AG',
      model:
        payload.model === 'gemini-3.1-flash-lite'
          ? 'gemini-3.1-flash-lite'
          : 'gemini-3.8-flash',
      systemInstruction: payload.systemInstruction,
      color: payload.color || 'indigo',
      connectedTools: payload.connectedTools || ['artifact_vault'],
      webhookUrl: payload.webhookUrl || '',
      githubRepo: payload.githubRepo || '',
      totalTokens: 0,
      totalRuns: 0,
      avgLatencyMs: 0,
      status: 'idle',
    };

    store.agents.push(newAgent);
    saveStore(store);
    res.json({ agent: newAgent });
  });

  // 3. Delete an agent
  app.delete('/api/agents/:id', (req, res) => {
    const { id } = req.params;
    if (store.agents.length <= 1) {
      res
        .status(400)
        .json({ error: 'At least one agent must remain in the workspace.' });
      return;
    }
    store.agents = store.agents.filter((a) => a.id !== id);
    saveStore(store);
    res.json({ ok: true });
  });

  // 4. Execute Parallel Swarm Broadcast across multiple agents
  app.post('/api/swarm/execute', async (req, res) => {
    try {
      const {
        prompt,
        agentIds,
        attachedFileIds = [],
        synthesize = true,
        saveAsArtifact = false,
      } = req.body as {
        prompt: string;
        agentIds: string[];
        attachedFileIds?: string[];
        synthesize?: boolean;
        saveAsArtifact?: boolean;
      };

      if (!prompt || !Array.isArray(agentIds) || agentIds.length === 0) {
        res.status(400).json({
          error: 'Please provide a command prompt and select at least one agent.',
        });
        return;
      }

      const selectedAgents = store.agents.filter((a) =>
        agentIds.includes(a.id)
      );
      if (selectedAgents.length === 0) {
        res.status(400).json({ error: 'No matching agents found.' });
        return;
      }

      // Build shared file context if user attached hosted files
      const attachedFiles = store.files.filter((f) =>
        attachedFileIds.includes(f.id)
      );
      const fileContext =
        attachedFiles.length > 0
          ? attachedFiles
              .map(
                (f) =>
                  `--- Hosted File: ${f.path} (${f.githubRef || f.category}) ---\n${f.content.slice(0, 4000)}`
              )
              .join('\n\n')
          : undefined;

      // Execute all selected agents in parallel!
      const results: SwarmAgentResult[] = await Promise.all(
        selectedAgents.map(async (agent): Promise<SwarmAgentResult> => {
          try {
            const { text, latencyMs, tokens } = await runSingleAgent(
              agent,
              prompt,
              fileContext
            );

            // Update agent stats
            agent.totalTokens += tokens;
            agent.totalRuns += 1;
            agent.avgLatencyMs =
              agent.avgLatencyMs === 0
                ? latencyMs
                : Math.round((agent.avgLatencyMs + latencyMs) / 2);

            store.usageLogs.unshift({
              id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
              timestamp: new Date().toISOString(),
              agentId: agent.id,
              agentName: agent.name,
              operation: 'Swarm Broadcast',
              tokens,
              latencyMs,
              status: 'success',
            });

            return {
              agentId: agent.id,
              agentName: agent.name,
              agentRole: agent.role,
              color: agent.color,
              content: text,
              latencyMs,
              tokens,
              status: 'completed',
            };
          } catch (err: any) {
            const errorMessage =
              err instanceof Error ? err.message : 'Agent execution failed';
            store.usageLogs.unshift({
              id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
              timestamp: new Date().toISOString(),
              agentId: agent.id,
              agentName: agent.name,
              operation: 'Swarm Broadcast',
              tokens: 0,
              latencyMs: 0,
              status: 'error',
            });
            return {
              agentId: agent.id,
              agentName: agent.name,
              agentRole: agent.role,
              color: agent.color,
              content: `Error executing ${agent.name}: ${errorMessage}`,
              latencyMs: 0,
              tokens: 0,
              status: 'error',
              error: errorMessage,
            };
          }
        })
      );

      let synthesisText: string | undefined;
      let savedArtifactPath: string | undefined;

      const successfulResults = results.filter((r) => r.status === 'completed');

      if (synthesize && successfulResults.length > 1) {
        try {
          const coordinator =
            store.agents.find((a) => a.id === 'agent-synthesizer') ||
            selectedAgents[0];
          const synthesisPrompt = `Synthesize the following parallel agent responses to the user command: "${prompt}".\nHighlight consensus recommendations, resolve trade-offs, and provide a unified action plan.\n\n${successfulResults
            .map(
              (r) =>
                `=== Agent: ${r.agentName} (${r.agentRole}) ===\n${r.content}`
            )
            .join('\n\n')}`;

          const synRes = await runSingleAgent(coordinator, synthesisPrompt);
          synthesisText = synRes.text;

          coordinator.totalTokens += synRes.tokens;
          coordinator.totalRuns += 1;
          store.usageLogs.unshift({
            id: `log-${Date.now()}-syn`,
            timestamp: new Date().toISOString(),
            agentId: coordinator.id,
            agentName: coordinator.name,
            operation: 'Consensus Synthesis',
            tokens: synRes.tokens,
            latencyMs: synRes.latencyMs,
            status: 'success',
          });
        } catch (synErr: any) {
          synthesisText = `Synthesis note: ${synErr?.message || 'Unable to synthesize automatically.'}`;
        }
      }

      if (saveAsArtifact) {
        const slug = prompt
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-|-$/g, '')
          .slice(0, 32);
        const fileName = `swarm-${slug || 'run'}-${Date.now().toString().slice(-4)}.md`;
        savedArtifactPath = `/artifacts/${fileName}`;

        const compiledMarkdown = `# Swarm Execution Artifact\n\n- **Command**: ${prompt}\n- **Executed At**: ${new Date().toISOString()}\n- **Agents Coordinated**: ${results.map((r) => r.agentName).join(', ')}\n\n${
          synthesisText
            ? `## Coordinator Consensus Synthesis\n\n${synthesisText}\n\n---\n\n`
            : ''
        }## Individual Parallel Agent Outputs\n\n${results
          .map(
            (r) =>
              `### ${r.agentName} (${r.agentRole}) — ${r.latencyMs}ms · ${r.tokens} tokens\n\n${r.content}`
          )
          .join('\n\n---\n\n')}`;

        const artifactFile: HostedFile = {
          id: `file-${Date.now()}`,
          path: savedArtifactPath,
          name: fileName,
          category: 'pipeline_artifact',
          language: 'markdown',
          sizeBytes: Buffer.byteLength(compiledMarkdown, 'utf-8'),
          content: compiledMarkdown,
          authorAgentName: 'Swarm Coordinator',
          githubRef: 'swarm/parallel-run',
          updatedAt: new Date().toISOString(),
        };

        store.files.unshift(artifactFile);
      }

      const newRun: SwarmRun = {
        id: `swarm-${Date.now()}`,
        prompt,
        timestamp: new Date().toISOString(),
        agentIds,
        results,
        synthesis: synthesisText,
        savedArtifactPath,
      };

      store.swarmRuns.unshift(newRun);
      saveStore(store);

      res.json({
        swarmRun: newRun,
        agents: store.agents,
        files: store.files,
      });
    } catch (error: any) {
      res.status(500).json({
        error: error?.message || 'Failed to execute parallel swarm command.',
      });
    }
  });

  // 5. Save or export an existing SwarmRun as a hosted artifact
  app.post('/api/swarm/:id/save-artifact', (req, res) => {
    const { id } = req.params;
    const run = store.swarmRuns.find((r) => r.id === id);
    if (!run) {
      res.status(404).json({ error: 'Swarm run not found.' });
      return;
    }

    const slug = run.prompt
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 32);
    const fileName = `swarm-${slug || 'report'}-${Date.now().toString().slice(-4)}.md`;
    const filePath = `/artifacts/${fileName}`;

    const content = `# Swarm Execution Report\n\n**Prompt**: ${run.prompt}\n**Timestamp**: ${run.timestamp}\n\n${
      run.synthesis ? `## Consensus Synthesis\n\n${run.synthesis}\n\n` : ''
    }## Agent Responses\n\n${run.results
      .map(
        (r) =>
          `### ${r.agentName} (${r.agentRole})\n*Latency: ${r.latencyMs}ms · Tokens: ${r.tokens}*\n\n${r.content}`
      )
      .join('\n\n---\n\n')}`;

    const newFile: HostedFile = {
      id: `file-${Date.now()}`,
      path: filePath,
      name: fileName,
      category: 'pipeline_artifact',
      language: 'markdown',
      sizeBytes: Buffer.byteLength(content, 'utf-8'),
      content,
      authorAgentName: 'Swarm Coordinator',
      githubRef: 'swarm/artifact',
      updatedAt: new Date().toISOString(),
    };

    run.savedArtifactPath = filePath;
    store.files.unshift(newFile);
    saveStore(store);

    res.json({ file: newFile, swarmRun: run });
  });

  // 6. Create or update a DAG Pipeline
  app.post('/api/pipelines', (req, res) => {
    const payload = req.body as DAGPipeline;
    if (!payload.name || !Array.isArray(payload.nodes)) {
      res.status(400).json({ error: 'Pipeline name and nodes are required.' });
      return;
    }

    const idx = store.pipelines.findIndex((p) => p.id === payload.id);
    if (idx >= 0) {
      store.pipelines[idx] = {
        ...store.pipelines[idx],
        ...payload,
      };
      saveStore(store);
      res.json({ pipeline: store.pipelines[idx] });
      return;
    }

    const created: DAGPipeline = {
      ...payload,
      id: payload.id || `pipe-${Date.now()}`,
      edges: payload.edges || [],
      lastStatus: 'idle',
    };
    store.pipelines.unshift(created);
    saveStore(store);
    res.json({ pipeline: created });
  });

  // 7. Execute a DAG Pipeline topologically
  app.post('/api/pipelines/:id/execute', async (req, res) => {
    try {
      const { id } = req.params;
      const { customInput } = req.body as { customInput?: string };
      const pipeline = store.pipelines.find((p) => p.id === id);
      if (!pipeline) {
        res.status(404).json({ error: 'Pipeline not found.' });
        return;
      }

      pipeline.lastStatus = 'running';
      const nodeOutputs = new Map<string, string>();

      // Group nodes into topological levels so independent nodes at the same level run in parallel
      const inDegree = new Map<string, number>();
      const parentsMap = new Map<string, string[]>();

      for (const node of pipeline.nodes) {
        inDegree.set(node.id, 0);
        parentsMap.set(node.id, []);
        node.status = 'idle';
        node.error = undefined;
      }

      for (const edge of pipeline.edges) {
        if (inDegree.has(edge.target) && inDegree.has(edge.source)) {
          inDegree.set(edge.target, (inDegree.get(edge.target) || 0) + 1);
          parentsMap.get(edge.target)?.push(edge.source);
        }
      }

      const remaining = new Set(pipeline.nodes.map((n) => n.id));

      while (remaining.size > 0) {
        const readyIds = Array.from(remaining).filter(
          (nodeId) => (inDegree.get(nodeId) || 0) <= 0
        );

        // Fallback if cycle exists: pick first remaining node
        const batchIds =
          readyIds.length > 0 ? readyIds : [Array.from(remaining)[0]];

        // Execute current topological wave in parallel
        await Promise.all(
          batchIds.map(async (nodeId) => {
            const node = pipeline.nodes.find((n) => n.id === nodeId)!;
            node.status = 'running';
            const parentIds = parentsMap.get(node.id) || [];
            const upstreamContext = [
              customInput ? `Pipeline Trigger Input: ${customInput}` : '',
              ...parentIds.map((pid) => {
                const parentNode = pipeline.nodes.find((n) => n.id === pid);
                return `Output from [${parentNode?.label || pid}]:\n${nodeOutputs.get(pid) || ''}`;
              }),
            ]
              .filter(Boolean)
              .join('\n\n');

            const startMs = Date.now();

            try {
              if (node.type === 'github_fetch') {
                const repoTarget =
                  node.repoTarget || 'modelcontextprotocol/servers';
                try {
                  const { summary, filesImported } =
                    await fetchGitHubRepoSummary(repoTarget);
                  for (const f of filesImported) {
                    const existingIdx = store.files.findIndex(
                      (ef) => ef.path === f.path
                    );
                    if (existingIdx >= 0) {
                      store.files[existingIdx] = f;
                    } else {
                      store.files.unshift(f);
                    }
                  }
                  node.lastOutput = summary;
                } catch (ghErr: any) {
                  node.lastOutput = `GitHub repository snapshot (${repoTarget}):\n${ghErr?.message || 'Using cached workspace index.'}`;
                }
                node.latencyMs = Math.max(80, Date.now() - startMs);
                node.tokens = 0;
                node.status = 'completed';
                nodeOutputs.set(node.id, node.lastOutput);
              } else if (node.type === 'api_webhook') {
                const targetUrl = node.webhookUrl || 'https://httpbin.org/post';
                let webhookSummary = '';
                try {
                  const whRes = await fetch(targetUrl, {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      'X-NexusFlow-Pipeline': pipeline.id,
                    },
                    body: JSON.stringify({
                      pipeline: pipeline.name,
                      node: node.label,
                      timestamp: new Date().toISOString(),
                      upstreamPreview: upstreamContext.slice(0, 600),
                    }),
                  });
                  webhookSummary = `Webhook POST -> ${targetUrl} returned HTTP ${whRes.status}. Payload delivered (${upstreamContext.length} chars).`;
                } catch (whErr: any) {
                  webhookSummary = `Webhook dispatch to ${targetUrl} logged: ${whErr?.message || 'Completed'}`;
                }
                node.lastOutput = webhookSummary;
                node.latencyMs = Math.max(60, Date.now() - startMs);
                node.tokens = 0;
                node.status = 'completed';
                nodeOutputs.set(node.id, node.lastOutput);
              } else if (node.type === 'artifact_save') {
                const targetPath =
                  node.outputPath ||
                  `/artifacts/${pipeline.id}-${Date.now().toString().slice(-4)}.md`;
                const fileName =
                  targetPath.split('/').filter(Boolean).pop() ||
                  'pipeline-artifact.md';
                const compiledBody = `# Pipeline Deliverable: ${pipeline.name}\n\n- **Generated At**: ${new Date().toISOString()}\n- **Pipeline ID**: \`${pipeline.id}\`\n\n---\n\n${upstreamContext || 'No upstream node outputs provided.'}`;

                const artifactFile: HostedFile = {
                  id: `file-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
                  path: targetPath.startsWith('/')
                    ? targetPath
                    : `/${targetPath}`,
                  name: fileName,
                  category: 'pipeline_artifact',
                  language: fileName.endsWith('.json') ? 'json' : 'markdown',
                  sizeBytes: Buffer.byteLength(compiledBody, 'utf-8'),
                  content: compiledBody,
                  authorAgentName: `Pipeline: ${pipeline.name}`,
                  githubRef: `dag/${pipeline.id}`,
                  updatedAt: new Date().toISOString(),
                };

                const existingFileIdx = store.files.findIndex(
                  (f) => f.path === artifactFile.path
                );
                if (existingFileIdx >= 0) {
                  store.files[existingFileIdx] = artifactFile;
                } else {
                  store.files.unshift(artifactFile);
                }

                node.lastOutput = `Saved ${artifactFile.sizeBytes} bytes to ${artifactFile.path}`;
                node.latencyMs = Math.max(25, Date.now() - startMs);
                node.tokens = 0;
                node.status = 'completed';
                nodeOutputs.set(node.id, node.lastOutput);
              } else {
                // Default: 'agent' node
                const agent =
                  store.agents.find((a) => a.id === node.agentId) ||
                  store.agents[0];
                const promptToRun =
                  node.prompt ||
                  `Execute step "${node.label}" for pipeline "${pipeline.name}".`;

                const { text, latencyMs, tokens } = await runSingleAgent(
                  agent,
                  promptToRun,
                  upstreamContext
                );

                node.lastOutput = text;
                node.latencyMs = latencyMs;
                node.tokens = tokens;
                node.status = 'completed';
                nodeOutputs.set(node.id, text);

                agent.totalTokens += tokens;
                agent.totalRuns += 1;
                agent.avgLatencyMs =
                  agent.avgLatencyMs === 0
                    ? latencyMs
                    : Math.round((agent.avgLatencyMs + latencyMs) / 2);

                store.usageLogs.unshift({
                  id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
                  timestamp: new Date().toISOString(),
                  agentId: agent.id,
                  agentName: agent.name,
                  operation: 'DAG Step',
                  tokens,
                  latencyMs,
                  status: 'success',
                });
              }
            } catch (nodeErr: any) {
              const errMsg =
                nodeErr instanceof Error
                  ? nodeErr.message
                  : 'Node execution failed';
              node.status = 'error';
              node.error = errMsg;
              node.lastOutput = `Error: ${errMsg}`;
              nodeOutputs.set(node.id, node.lastOutput);
            }
          })
        );

        // Remove batchIds and decrement downstream inDegrees
        for (const completedId of batchIds) {
          remaining.delete(completedId);
          for (const edge of pipeline.edges) {
            if (edge.source === completedId && remaining.has(edge.target)) {
              inDegree.set(edge.target, (inDegree.get(edge.target) || 1) - 1);
            }
          }
        }
      }

      const hasError = pipeline.nodes.some((n) => n.status === 'error');
      pipeline.lastStatus = hasError ? 'error' : 'completed';
      pipeline.lastRunAt = new Date().toISOString();
      saveStore(store);

      res.json({
        pipeline,
        agents: store.agents,
        files: store.files,
      });
    } catch (err: any) {
      res.status(500).json({
        error: err?.message || 'Failed to execute DAG pipeline.',
      });
    }
  });

  // 8. Create or update a Hosted File in the File Vault
  app.post('/api/files', (req, res) => {
    const { id, path: rawPath, name, content, category, language, githubRef } =
      req.body as Partial<HostedFile>;

    if (!content && content !== '') {
      res.status(400).json({ error: 'File content is required.' });
      return;
    }

    const cleanName =
      name ||
      rawPath?.split('/').filter(Boolean).pop() ||
      `artifact-${Date.now()}.md`;
    const cleanPath = rawPath
      ? rawPath.startsWith('/')
        ? rawPath
        : `/${rawPath}`
      : `/workspace/${cleanName}`;

    const ext = cleanName.split('.').pop()?.toLowerCase() || 'md';
    const inferredLang =
      language ||
      (ext === 'json'
        ? 'json'
        : ext === 'ts' || ext === 'tsx'
          ? 'typescript'
          : ext === 'py'
            ? 'python'
            : 'markdown');

    const existingIdx = store.files.findIndex(
      (f) => f.id === id || f.path === cleanPath
    );

    if (existingIdx >= 0) {
      store.files[existingIdx] = {
        ...store.files[existingIdx],
        name: cleanName,
        path: cleanPath,
        content,
        language: inferredLang,
        sizeBytes: Buffer.byteLength(content, 'utf-8'),
        updatedAt: new Date().toISOString(),
        ...(githubRef ? { githubRef } : {}),
      };
      saveStore(store);
      res.json({ file: store.files[existingIdx] });
      return;
    }

    const newFile: HostedFile = {
      id: `file-${Date.now()}`,
      path: cleanPath,
      name: cleanName,
      category: category || 'user_upload',
      language: inferredLang,
      sizeBytes: Buffer.byteLength(content, 'utf-8'),
      content,
      authorAgentName: 'Workspace User',
      githubRef: githubRef || 'local/workspace',
      updatedAt: new Date().toISOString(),
    };

    store.files.unshift(newFile);
    saveStore(store);
    res.json({ file: newFile });
  });

  // 9. Delete a Hosted File
  app.delete('/api/files/:id', (req, res) => {
    const { id } = req.params;
    store.files = store.files.filter((f) => f.id !== id);
    saveStore(store);
    res.json({ ok: true });
  });

  // 10. Sync a public GitHub repository into the Hosted File Vault
  app.post('/api/github/sync', async (req, res) => {
    try {
      const { repo } = req.body as { repo: string };
      if (!repo || !repo.trim()) {
        res
          .status(400)
          .json({ error: 'Please provide a GitHub repository (owner/repo).' });
        return;
      }

      const { summary, filesImported } = await fetchGitHubRepoSummary(repo);

      for (const file of filesImported) {
        const idx = store.files.findIndex((f) => f.path === file.path);
        if (idx >= 0) {
          store.files[idx] = file;
        } else {
          store.files.unshift(file);
        }
      }

      saveStore(store);
      res.json({
        summary,
        importedCount: filesImported.length,
        files: store.files,
      });
    } catch (err: any) {
      res.status(400).json({
        error: err?.message || 'Failed to sync from GitHub.',
      });
    }
  });

  // Vite middleware for development or static serving for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    app.use(vite.middlewares);
    app.use('*', async (req, res, next) => {
      if (req.originalUrl.startsWith('/api/')) {
        return next();
      }
      try {
        let template = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(req.originalUrl, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NexusFlow AI Server running on http://localhost:${PORT}`);
  });
}

startServer();
