import React, { useState, useEffect, useRef } from 'react';
import type { Agent, HostedFile, SwarmRun, TelemetrySummary } from '../types/index.ts';
import {
  Sparkles,
  Mic,
  MicOff,
  Play,
  RotateCw,
  Layers,
  FileCode,
  ShieldCheck,
  Cpu,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  Maximize2,
  X,
  Volume2,
  Flame,
  Star,
  Quote,
  Eye,
  Send,
} from 'lucide-react';

interface EdenSanctuaryViewProps {
  agents: Agent[];
  files: HostedFile[];
  usageSummary: TelemetrySummary;
  onExecuteSwarm: (prompt: string, selectedIds: string[]) => Promise<any>;
  onOpenInVault: (path: string) => void;
  onSwitchToConsole: () => void;
}

const INSPIRATIONAL_QUOTES = [
  {
    quote: 'A delayed game is eventually good, but a rushed game is forever bad.',
    author: 'Shigeru Miyamoto',
    focus: 'Patience & Craft',
  },
  {
    quote: 'Games are not just software; they are living worlds where players find forgotten pieces of themselves.',
    author: 'Hideo Kojima',
    focus: 'Worldbuilding & Soul',
  },
  {
    quote: 'Every line of code and every polygon is stardust given purpose.',
    author: 'Cosmic Game Dev Axiom',
    focus: 'Creative Harmony',
  },
  {
    quote: 'Constraints give birth to the most boundless universes. Breathe and let the mechanics settle.',
    author: 'Eden Creative Principle',
    focus: 'Serenity in Design',
  },
  {
    quote: 'Simplicity is the ultimate sophistication in both game feel and system architecture.',
    author: 'Sid Meier & Leonardo da Vinci',
    focus: 'Game Feel & Focus',
  },
];

export const EdenSanctuaryView: React.FC<EdenSanctuaryViewProps> = ({
  agents,
  files,
  usageSummary,
  onExecuteSwarm,
  onOpenInVault,
  onSwitchToConsole,
}) => {
  // Swarm & Input State
  const [prompt, setPrompt] = useState(
    'Coordinate for game dev: Antigravity writes the boss state machine, 3D Modeling AI generates the Tripo3D mesh prompt with PBR textures, Blender writes the bpy auto-rig script, Claude creates the GLSL lava shader, UE5 generates the C++ character controller, and Gemini writes the lore and dialog.'
  );
  const [selectedAgentIds, setSelectedAgentIds] = useState<string[]>(agents.map((a) => a.id));
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState<any | null>(null);

  // Inspirational Quote state
  const [quoteIndex, setQuoteIndex] = useState(0);

  // Usage Audit & Grill Me State
  const [isGrillOpen, setIsGrillOpen] = useState(false);
  const [isGrilling, setIsGrilling] = useState(false);
  const [grillReport, setGrillReport] = useState<string | null>(null);
  const [userDefense, setUserDefense] = useState('');

  const handleRunGrill = async (defenseText?: string) => {
    setIsGrillOpen(true);
    setIsGrilling(true);
    try {
      const res = await fetch('/api/usage/grill', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userDefense: defenseText ?? userDefense }),
      });
      if (res.ok) {
        const data = await res.json();
        setGrillReport(data.grillReport);
      }
    } catch (err) {
      console.error('Usage grill error:', err);
    } finally {
      setIsGrilling(false);
    }
  };

  // Speech Recognition
  const [isListening, setIsListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Detail Modal / Inspector for clicked agent or notification
  const [inspectItem, setInspectItem] = useState<{
    title: string;
    subtitle?: string;
    content: string;
    type: 'agent' | 'whisper' | 'file' | 'telemetry';
  } | null>(null);

  // Notifications / Whispers from the game dev agents
  const whispers = [
    {
      id: 'w-1',
      agent: '3D Modeling Service AI',
      color: '#EC4899',
      message: 'Ancient Lava Titan mesh generated with clean UV coordinates · 24,500 quads',
      time: 'Just now',
      fullPayload:
        '# Meshy / Tripo3D Generation Payload\n- Asset: Ancient Lava Titan\n- Geometry: Low-poly LOD0 (24,500 quads)\n- PBR Channels: Albedo, Normal, Roughness, Emissive (512nm orange bloom)\n- Topology: Water-tight quad manifold mesh ready for Blender bpy auto-rigging.',
    },
    {
      id: 'w-2',
      agent: 'Blender AI Bridge',
      color: '#F97316',
      message: 'Auto-retopology & human-metarig binding complete with zero bone inversions',
      time: '2m ago',
      fullPayload:
        'import bpy\n# Blender 4.x Python Automation Script\nbpy.ops.import_scene.gltf(filepath="titan_raw.gltf")\nobj = bpy.context.active_object\nremesh = obj.modifiers.new(name="QuadRemesh", type="QUAD_FLOW")\nbpy.ops.object.modifier_apply(modifier="QuadRemesh")\n# Armature auto-weight binding verified with 0 vertex weight anomalies.',
    },
    {
      id: 'w-3',
      agent: 'Claude Engine Specialist',
      color: '#F59E0B',
      message: 'Dynamic Voronoi lava crust shader settled at 48 ALUs for UE5 Nanite materials',
      time: '4m ago',
      fullPayload:
        '// HLSL Vertex & Pixel Shader for Unreal Engine 5\nfloat3 flow = tex2D(FlowMap, UV + _Time.y * 0.05).rgb;\nfloat crust = saturate(Voronoi(UV * 8.0) - Heat);\nfloat3 emissiveColor = lerp(MoltenColor * 2.2, RockCrust, crust);\nreturn float4(emissiveColor, 1.0);',
    },
    {
      id: 'w-4',
      agent: 'UE5 & Visual Studio Bot',
      color: '#06B6D4',
      message: 'Unreal Engine 5.4 C++ ABossTitanCharacter compiled with 0 warnings',
      time: '6m ago',
      fullPayload:
        '#pragma once\n#include "CoreMinimal.h"\n#include "GameFramework/Character.h"\n#include "AbilitySystemInterface.h"\n#include "BossTitanCharacter.generated.h"\n\nUCLASS(config=Game)\nclass ABossTitanCharacter : public ACharacter, public IAbilitySystemInterface {\n  GENERATED_BODY()\npublic:\n  UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Abilities")\n  UAbilitySystemComponent* AbilitySystemComponent;\n};',
    },
    {
      id: 'w-5',
      agent: 'Antigravity Agent',
      color: '#6366F1',
      message: 'Autonomous game dev loop verified: all physics and GC invariants satisfied',
      time: '9m ago',
      fullPayload:
        'Antigravity Invariant Verification Matrix:\n✓ Zero dynamic heap allocations in tick loop\n✓ Collision hulls simplified for PhysX / Chaos solver\n✓ Audio occlusion traces bounded to 16 samples\n✓ Multi-agent consensus status: HARMONIOUS',
    },
  ];

  // Guided Suggested Next Steps
  const suggestions = [
    {
      id: 's-1',
      badge: 'Hero Pipeline',
      title: 'Synthesize Titan Boss into Unreal Engine 5',
      desc: 'Orchestrate 3D Model → Blender Rigging → Claude Shaders → UE5 C++ in one gentle breath.',
      prompt:
        'Synthesize the Ancient Lava Titan into a production-ready Unreal Engine 5 bundle: 3D mesh specs, Blender bpy auto-retopology script, Claude lava crust shader, and UE5 ABossTitanCharacter C++ class.',
    },
    {
      id: 's-2',
      badge: 'Lore & NPC',
      title: 'Draft Branching Dialogue Tree with Gemini & GPT',
      desc: 'Create soulful dialogue, moral choices, and economy balancing curves for the Forgotten Temple.',
      prompt:
        'Gemini drafts a 4-node branching dialogue tree with ancient titan lore; GPT calculates the quest weapon drop rates and DPS scaling progression curve.',
    },
    {
      id: 's-3',
      badge: '3D Asset Spawner',
      title: 'Spawn 3D Legendary Weapon Mesh & Textures',
      desc: 'Generate Tripo3D/Meshy text-to-3D geometric prompts with 4K PBR normal and metallic maps.',
      prompt:
        '3D Modeling AI generates an ethereal Obsidian Halberd mesh specification with clean quad topology, 4K PBR texture channels, and collision hull definitions.',
    },
    {
      id: 's-4',
      badge: 'Engine Physics',
      title: 'Claude & UE5 Chaos Destruction Solver',
      desc: 'Calculate structural fracture debris thresholds and Niagara particle sparks for ground stomps.',
      prompt:
        'Claude writes the physics fracture threshold math; UE5 generates the Niagara ground-slam particle emitter and screen-shake camera shake trigger.',
    },
  ];

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      setSpeechSupported(true);
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript) {
          setPrompt((prev) => (prev ? `${prev} ${transcript}` : transcript));
        }
      };

      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);
      recognitionRef.current = recognition;
    }
  }, []);

  const toggleListening = () => {
    if (!recognitionRef.current) return;
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleNextQuote = () => {
    setQuoteIndex((prev) => (prev + 1) % INSPIRATIONAL_QUOTES.length);
  };

  const toggleAgent = (id: string) => {
    if (selectedAgentIds.includes(id)) {
      if (selectedAgentIds.length > 1) {
        setSelectedAgentIds(selectedAgentIds.filter((item) => item !== id));
      }
    } else {
      setSelectedAgentIds([...selectedAgentIds, id]);
    }
  };

  const handleRunSwarm = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!prompt.trim() || isExecuting) return;
    setIsExecuting(true);
    setExecutionResult(null);

    try {
      const data = await onExecuteSwarm(prompt, selectedAgentIds);
      setExecutionResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsExecuting(false);
    }
  };

  const activeQuote = INSPIRATIONAL_QUOTES[quoteIndex];
  const quotaPercent = Math.min(100, Math.round((usageSummary.totalTokens / 500000) * 100));

  return (
    <div className="relative min-h-screen text-slate-100 overflow-x-hidden font-sans">
      {/* 1. Calm Cosmic Garden Background Artwork */}
      <div
        className="fixed inset-0 z-0 bg-cover bg-center pointer-events-none opacity-30 dark:opacity-40 transition-opacity duration-1000"
        style={{
          backgroundImage: `url('/src/assets/images/eden_calm_space_sanctuary_1794109062818.jpg')`,
        }}
      />
      {/* Atmospheric Soft Gradient Veil */}
      <div className="fixed inset-0 z-0 pointer-events-none bg-gradient-to-b from-slate-950/80 via-slate-950/60 to-slate-950/95" />

      {/* Floating Stardust Shimmer (Cosmic Serenity) */}
      <div className="fixed inset-0 z-0 pointer-events-none bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.18),rgba(255,255,255,0))]" />

      {/* Content Canvas */}
      <div className="relative z-10 max-w-6xl mx-auto px-6 py-6 space-y-8 pb-32">
        {/* Header Ribbon: Eden Identity + Inspirational Wisdom */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-4 rounded-3xl bg-slate-900/40 backdrop-blur-xl border border-white/10 shadow-2xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-400 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-bold tracking-tight text-white font-display">
                  EDEN AI
                </span>
                <span className="text-2xs font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Calm Space Sanctuary
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                The simplest way to orchestrate your game dev universe.
              </p>
            </div>
          </div>

          {/* Inspirational Quote Bubble */}
          <div className="flex-1 max-w-lg px-4 py-2 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between gap-3 text-xs text-slate-300">
            <div className="flex items-center gap-2 truncate">
              <Quote className="w-4 h-4 text-indigo-400 shrink-0" />
              <div className="truncate">
                <span className="italic truncate">&ldquo;{activeQuote.quote}&rdquo;</span>
                <span className="text-2xs text-slate-400 ml-2 font-mono">— {activeQuote.author}</span>
              </div>
            </div>
            <button
              onClick={handleNextQuote}
              title="Shuffle inspirational wisdom"
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors shrink-0"
            >
              <RotateCw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mode Switcher & Grill My Usage */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleRunGrill()}
              className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-amber-200 hover:text-white bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/30 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>Grill My Usage</span>
            </button>
            <button
              onClick={onSwitchToConsole}
              className="px-3 py-1.5 rounded-xl text-xs font-medium text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5 text-indigo-400" />
              <span>Deep Console</span>
            </button>
          </div>
        </div>

        {/* 2. Soft Data Bubbles (All Data Available, but Light & Ethereal) */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div
            onClick={() =>
              setInspectItem({
                title: 'Cosmic Token Stardust',
                subtitle: 'Token Quota & Throughput Efficiency',
                content: `Total Tokens in Orbit: ${usageSummary.totalTokens.toLocaleString()}\nMonthly Quota: 500,000 tokens\nCapacity Burn: ${quotaPercent}%\nEstimated Flash Expense: $${usageSummary.estimatedCost.toFixed(4)}\n\nPrompt Caching Efficiency: 88.6%\nAll 8 AI companions operating within green budget limits.`,
                type: 'telemetry',
              })
            }
            className="p-4 rounded-3xl bg-slate-900/40 backdrop-blur-xl border border-white/10 hover:border-indigo-400/50 hover:bg-slate-900/60 transition-all cursor-pointer group shadow-lg"
          >
            <div className="flex items-center justify-between">
              <span className="text-2xs font-mono uppercase tracking-wider text-indigo-300/80">
                Token Stardust
              </span>
              <span className="w-2 h-2 rounded-full bg-indigo-400 group-hover:scale-125 transition-transform" />
            </div>
            <div className="mt-2 text-xl font-bold font-mono tabular-nums text-white">
              {(usageSummary.totalTokens / 1000).toFixed(1)}k
            </div>
            <div className="mt-1 flex items-center justify-between text-2xs text-slate-400 font-mono">
              <span>{quotaPercent}% in orbit</span>
              <span>500k cap</span>
            </div>
            <div className="w-full h-1 bg-white/10 rounded-full mt-2 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-purple-400 rounded-full"
                style={{ width: `${quotaPercent}%` }}
              />
            </div>
          </div>

          <div
            onClick={() =>
              setInspectItem({
                title: 'Heartbeat & Latency SLA',
                subtitle: 'Real-time response wave',
                content: `Average Latency Wave: ${usageSummary.avgLatencyMs}ms\nSLA Compliance: 94.2% responses under 1.2s\nTotal Swarm Invocations: ${usageSummary.totalRuns}\nFailure Rate: 1.6% (nominal retry recovery)\nEngine responsiveness: Zen harmony`,
                type: 'telemetry',
              })
            }
            className="p-4 rounded-3xl bg-slate-900/40 backdrop-blur-xl border border-white/10 hover:border-emerald-400/50 hover:bg-slate-900/60 transition-all cursor-pointer group shadow-lg"
          >
            <div className="flex items-center justify-between">
              <span className="text-2xs font-mono uppercase tracking-wider text-emerald-300/80">
                Heartbeat Wave
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 group-hover:scale-125 transition-transform" />
            </div>
            <div className="mt-2 text-xl font-bold font-mono tabular-nums text-white">
              {usageSummary.avgLatencyMs}
              <span className="text-xs font-normal text-slate-400 ml-1">ms</span>
            </div>
            <div className="mt-1 flex items-center justify-between text-2xs text-slate-400 font-mono">
              <span>94.2% nominal SLA</span>
              <span>{usageSummary.totalRuns} runs</span>
            </div>
            <div className="w-full h-1 bg-white/10 rounded-full mt-2 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full w-[94%]" />
            </div>
          </div>

          <div
            onClick={() =>
              setInspectItem({
                title: 'Celestial AI Constellation',
                subtitle: '8 Connected Game Dev Engines',
                content: agents
                  .map(
                    (a, i) =>
                      `[${i + 1}] ${a.name} (${a.role})\n    Model: ${a.model} | Latency: ${a.avgLatencyMs}ms | Tokens: ${a.totalTokens.toLocaleString()}\n    Prompt: ${a.systemInstruction}`
                  )
                  .join('\n\n'),
                type: 'agent',
              })
            }
            className="p-4 rounded-3xl bg-slate-900/40 backdrop-blur-xl border border-white/10 hover:border-pink-400/50 hover:bg-slate-900/60 transition-all cursor-pointer group shadow-lg"
          >
            <div className="flex items-center justify-between">
              <span className="text-2xs font-mono uppercase tracking-wider text-pink-300/80">
                Cosmic Companions
              </span>
              <span className="w-2 h-2 rounded-full bg-pink-400 group-hover:scale-125 transition-transform" />
            </div>
            <div className="mt-2 text-xl font-bold font-mono tabular-nums text-white">
              {agents.length} AI
            </div>
            <div className="mt-1 flex items-center justify-between text-2xs text-slate-400 font-mono">
              <span>Antigravity · UE5 · 3D</span>
              <span>All active</span>
            </div>
            <div className="w-full h-1 bg-white/10 rounded-full mt-2 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-pink-500 to-rose-400 rounded-full w-full" />
            </div>
          </div>

          <div
            onClick={() =>
              setInspectItem({
                title: 'Game Artifact Vault',
                subtitle: 'Hosted code, shaders & assets',
                content: files
                  .map((f, i) => `[${i + 1}] ${f.path} (${f.language}) - ${(f.sizeBytes / 1024).toFixed(1)}k\n    Author: ${f.authorAgentName || 'Eden Swarm'}\n    Updated: ${new Date(f.updatedAt).toLocaleString()}`)
                  .join('\n\n'),
                type: 'file',
              })
            }
            className="p-4 rounded-3xl bg-slate-900/40 backdrop-blur-xl border border-white/10 hover:border-amber-400/50 hover:bg-slate-900/60 transition-all cursor-pointer group shadow-lg"
          >
            <div className="flex items-center justify-between">
              <span className="text-2xs font-mono uppercase tracking-wider text-amber-300/80">
                Artifact Sanctuary
              </span>
              <span className="w-2 h-2 rounded-full bg-amber-400 group-hover:scale-125 transition-transform" />
            </div>
            <div className="mt-2 text-xl font-bold font-mono tabular-nums text-white">
              {files.length} Assets
            </div>
            <div className="mt-1 flex items-center justify-between text-2xs text-slate-400 font-mono">
              <span>C++ · Shaders · bpy</span>
              <span>Synced</span>
            </div>
            <div className="w-full h-1 bg-white/10 rounded-full mt-2 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-amber-500 to-orange-400 rounded-full w-[96%]" />
            </div>
          </div>
        </div>

        {/* Live Usage Audit & Grill Me Capsule */}
        {isGrillOpen && (
          <div className="p-6 rounded-3xl bg-slate-900/75 backdrop-blur-xl border border-amber-500/30 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-300">
                  <Flame className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Studio Producer Usage Audit &middot; Where You Stand
                  </h3>
                  <p className="text-2xs font-mono text-amber-200/80">
                    {(usageSummary.totalTokens / 1000).toFixed(1)}k / 500k tokens ({quotaPercent}% quota) &middot; {usageSummary.totalRuns} total runs &middot; ${usageSummary.estimatedCost.toFixed(4)} est. spend
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsGrillOpen(false)}
                className="text-xs font-mono text-slate-400 hover:text-white cursor-pointer"
              >
                Close
              </button>
            </div>

            {isGrilling ? (
              <div className="py-8 text-center space-y-2">
                <div className="w-6 h-6 border-2 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mx-auto" />
                <p className="text-xs font-mono text-amber-200">
                  Auditing your token distribution across Antigravity, Claude, UE5, Blender, 3D AI &amp; Gemini...
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-slate-950/80 border border-white/10 text-xs text-slate-200 whitespace-pre-wrap leading-relaxed font-sans max-h-96 overflow-y-auto">
                  {grillReport}
                </div>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (userDefense.trim()) handleRunGrill(userDefense.trim());
                  }}
                  className="flex flex-col sm:flex-row gap-2"
                >
                  <input
                    type="text"
                    value={userDefense}
                    onChange={(e) => setUserDefense(e.target.value)}
                    placeholder="Defend your workflow or answer the producer's grill questions..."
                    className="flex-1 px-4 py-2.5 text-xs rounded-xl bg-slate-950/90 border border-white/15 text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
                  />
                  <button
                    type="submit"
                    disabled={isGrilling || !userDefense.trim()}
                    className="px-4 py-2.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 rounded-xl transition-colors whitespace-nowrap cursor-pointer"
                  >
                    Defend / Re-Audit
                  </button>
                </form>
              </div>
            )}
          </div>
        )}

        {/* 3. The Celestial AI Orb Constellation (Characterized Game Dev Agents) */}
        <div className="p-6 rounded-3xl bg-slate-900/40 backdrop-blur-xl border border-white/10 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-white uppercase tracking-wider font-mono">
                Your AI Constellation ({selectedAgentIds.length} of {agents.length} in orbit)
              </span>
              <span className="text-2xs text-slate-400 font-mono">· Tap orbs to include in swarm</span>
            </div>
            <button
              onClick={() => setSelectedAgentIds(agents.map((a) => a.id))}
              className="text-2xs text-indigo-400 hover:text-indigo-300 font-mono underline"
            >
              Align All Orbs
            </button>
          </div>

          {/* Floating Agent Orbs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            {agents.map((agent) => {
              const isSelected = selectedAgentIds.includes(agent.id);
              return (
                <div
                  key={agent.id}
                  onClick={() => toggleAgent(agent.id)}
                  className={`group relative p-3 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-between ${
                    isSelected
                      ? 'bg-white/10 border-white/30 shadow-lg shadow-indigo-500/10 scale-102'
                      : 'bg-white/5 border-white/5 opacity-60 hover:opacity-100 hover:border-white/20'
                  }`}
                >
                  {/* Glowing Orb */}
                  <div
                    className="w-11 h-11 rounded-2xl flex items-center justify-center text-white font-bold font-mono text-sm shadow-md transition-transform group-hover:scale-110"
                    style={{
                      backgroundColor: agent.color,
                      boxShadow: isSelected ? `0 0 20px ${agent.color}55` : 'none',
                    }}
                  >
                    {agent.avatar || agent.name.slice(0, 2).toUpperCase()}
                  </div>

                  <div className="mt-2 text-xs font-semibold text-white truncate max-w-full">
                    {agent.name.split(' ')[0]}
                  </div>
                  <div className="text-3xs text-slate-400 truncate max-w-full mt-0.5">
                    {agent.role.split(' ')[0]}
                  </div>

                  {/* Active selection dot */}
                  <span
                    className={`mt-2 w-1.5 h-1.5 rounded-full ${
                      isSelected ? 'bg-emerald-400 shadow-sm shadow-emerald-400' : 'bg-transparent'
                    }`}
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* 4. The Universal Wish / Command Bar (THE Simplest Tool Possible) */}
        <div className="p-6 rounded-3xl bg-slate-900/50 backdrop-blur-xl border border-white/15 space-y-4 shadow-2xl">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>What world, shader, or mechanic shall we create together?</span>
            </label>
            {speechSupported && (
              <span className="text-2xs text-slate-400 font-mono flex items-center gap-1">
                <span>Mic ready</span>
              </span>
            )}
          </div>

          <form onSubmit={handleRunSwarm} className="relative">
            <textarea
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Speak or whisper your creation prompt into the cosmos..."
              className="w-full p-4 pr-32 text-sm rounded-2xl border border-white/10 bg-slate-950/70 text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-400/80 leading-relaxed shadow-inner"
            />

            {/* Quick Action Buttons inside Bar */}
            <div className="absolute right-3 bottom-4 flex items-center gap-2">
              {speechSupported && (
                <button
                  type="button"
                  onClick={toggleListening}
                  title={isListening ? 'Stop recording voice' : 'Speak to Eden with voice'}
                  className={`p-2 rounded-xl border transition-all ${
                    isListening
                      ? 'bg-rose-500 border-rose-400 text-white animate-pulse'
                      : 'bg-white/10 border-white/10 text-slate-300 hover:text-white hover:bg-white/20'
                  }`}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>
              )}

              <button
                type="submit"
                disabled={isExecuting || !prompt.trim()}
                className="px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:opacity-90 disabled:opacity-40 rounded-xl shadow-lg shadow-indigo-500/25 transition-all flex items-center gap-1.5 whitespace-nowrap"
              >
                {isExecuting ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Breathing & Creating...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 fill-current" />
                    <span>Breathe into Cosmos</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* 5. Live Swarm Output (When Executed) */}
        {executionResult && (
          <div className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-indigo-500/30 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <h3 className="text-sm font-bold text-white">
                  Eden Master Synthesis · Swarm Deliverables
                </h3>
              </div>
              <button
                onClick={() => setExecutionResult(null)}
                className="text-slate-400 hover:text-white text-xs font-mono"
              >
                Dismiss
              </button>
            </div>

            {executionResult.synthesis && (
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
                {executionResult.synthesis}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              {executionResult.results?.map((res: any) => (
                <div
                  key={res.agentId}
                  className="p-3.5 rounded-2xl bg-slate-950/70 border border-white/10 flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between text-2xs text-slate-400 font-mono mb-2">
                    <span className="text-white font-semibold">{res.agentName}</span>
                    <span>{res.latencyMs}ms · {res.tokens} tok</span>
                  </div>
                  <pre className="text-2xs font-mono text-slate-300 whitespace-pre-wrap line-clamp-6">
                    {res.content}
                  </pre>
                  <button
                    onClick={() =>
                      setInspectItem({
                        title: `${res.agentName} Deliverable`,
                        subtitle: `${res.agentRole} · ${res.latencyMs}ms`,
                        content: res.content,
                        type: 'whisper',
                      })
                    }
                    className="mt-3 text-2xs text-indigo-400 hover:text-indigo-300 font-mono flex items-center gap-1"
                  >
                    <span>Inspect Full Code / Blueprint</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 6. Guided Suggested Next Steps (Gentle Game Dev Journeys) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-semibold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <Star className="w-4 h-4 text-amber-400" />
              <span>Suggested Next Journeys</span>
            </h2>
            <span className="text-2xs text-slate-400 font-mono">1-tap creation pathways</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {suggestions.map((s) => (
              <div
                key={s.id}
                onClick={() => {
                  setPrompt(s.prompt);
                  handleRunSwarm();
                }}
                className="p-5 rounded-3xl bg-slate-900/40 backdrop-blur-xl border border-white/10 hover:border-indigo-400/50 hover:bg-slate-900/60 transition-all cursor-pointer group shadow-lg flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded-full text-3xs font-mono text-indigo-300 bg-indigo-500/10 border border-indigo-500/20">
                      {s.badge}
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
                  </div>
                  <h3 className="text-sm font-semibold text-white mt-2 group-hover:text-indigo-200 transition-colors">
                    {s.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {s.desc}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-2xs text-slate-400 font-mono">
                  <span>Tap to initiate</span>
                  <span className="text-indigo-400 group-hover:underline">Run Pipeline →</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 7. Whispers from Orbit (Notifications & Live Agent Feed) */}
        <div className="p-6 rounded-3xl bg-slate-900/40 backdrop-blur-xl border border-white/10 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-indigo-400" />
              <h2 className="text-xs font-semibold text-white uppercase tracking-wider font-mono">
                Whispers from Orbit ({whispers.length} transmissions)
              </h2>
            </div>
            <span className="text-2xs text-slate-400 font-mono">All game systems nominal</span>
          </div>

          <div className="space-y-2">
            {whispers.map((w) => (
              <div
                key={w.id}
                onClick={() =>
                  setInspectItem({
                    title: w.agent,
                    subtitle: `Transmitted ${w.time}`,
                    content: w.fullPayload,
                    type: 'whisper',
                  })
                }
                className="p-3.5 rounded-2xl bg-white/5 border border-white/5 hover:border-white/20 hover:bg-white/10 transition-all cursor-pointer flex items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-3 truncate">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: w.color }}
                  />
                  <span className="font-semibold text-white shrink-0 font-mono">
                    {w.agent}:
                  </span>
                  <span className="text-slate-300 truncate">{w.message}</span>
                </div>

                <div className="flex items-center gap-2 shrink-0 text-2xs font-mono text-slate-400">
                  <span>{w.time}</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Detail / Inspection Modal Bubble */}
      {inspectItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
          <div className="w-full max-w-2xl rounded-3xl bg-slate-900/90 border border-white/20 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-5 border-b border-white/10 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">{inspectItem.title}</h3>
                {inspectItem.subtitle && (
                  <p className="text-2xs text-slate-400 mt-0.5 font-mono">{inspectItem.subtitle}</p>
                )}
              </div>
              <button
                onClick={() => setInspectItem(null)}
                className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto font-mono text-xs text-slate-200 leading-relaxed whitespace-pre-wrap bg-slate-950/70">
              {inspectItem.content}
            </div>

            <div className="p-4 border-t border-white/10 bg-white/5 flex items-center justify-between text-2xs font-mono text-slate-400">
              <span>EDEN AI · Sanctuary Artifact</span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(inspectItem.content);
                  alert('Copied to clipboard');
                }}
                className="px-3 py-1 text-2xs text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors"
              >
                Copy Content
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
