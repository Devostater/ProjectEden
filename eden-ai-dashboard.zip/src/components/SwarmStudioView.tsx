import React, { useState, useRef } from 'react';
import {
  Play,
  Mic,
  MicOff,
  FileCode,
  Sparkles,
  Copy,
  Check,
  Archive,
  Clock,
  Layers,
  ArrowRight,
} from 'lucide-react';
import type { Agent, SwarmRun, HostedFile } from '../types';

interface SwarmStudioViewProps {
  agents: Agent[];
  swarmRuns: SwarmRun[];
  files: HostedFile[];
  selectedAgentIds: string[];
  onChangeSelectedAgents: (ids: string[]) => void;
  preselectedFileId?: string | null;
  onExecuteSwarm: (params: {
    prompt: string;
    agentIds: string[];
    attachedFileIds: string[];
    synthesize: boolean;
    saveAsArtifact: boolean;
  }) => Promise<SwarmRun>;
  onSaveRunToVault: (runId: string) => Promise<void>;
  onOpenArtifactInVault: (filePath: string) => void;
  onSwitchToDAGMode: () => void;
}

const PRESET_PROMPTS = [
  'Audit our webhook & GitHub ingestion architecture for race conditions, SSRF risks, and CI/CD bottlenecks.',
  'Design a parallel TypeScript worker pool that coordinates 4 LLM agents with exponential backoff and artifact caching.',
  'Generate a production security checklist, OpenAPI contract, and deployment workflow for a multi-tenant AI API.',
];

export const SwarmStudioView: React.FC<SwarmStudioViewProps> = ({
  agents,
  swarmRuns,
  files,
  selectedAgentIds,
  onChangeSelectedAgents,
  preselectedFileId,
  onExecuteSwarm,
  onSaveRunToVault,
  onOpenArtifactInVault,
  onSwitchToDAGMode,
}) => {
  const [prompt, setPrompt] = useState('');
  const [attachedFileIds, setAttachedFileIds] = useState<string[]>(
    preselectedFileId ? [preselectedFileId] : []
  );
  const [synthesize, setSynthesize] = useState(true);
  const [saveAsArtifact, setSaveAsArtifact] = useState(true);
  const [isExecuting, setIsExecuting] = useState(false);
  const [activeRunId, setActiveRunId] = useState<string | null>(
    swarmRuns[0]?.id || null
  );
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [voiceNote, setVoiceNote] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  const activeRun =
    swarmRuns.find((r) => r.id === activeRunId) || swarmRuns[0] || null;

  const toggleAgent = (id: string) => {
    if (selectedAgentIds.includes(id)) {
      if (selectedAgentIds.length > 1) {
        onChangeSelectedAgents(selectedAgentIds.filter((item) => item !== id));
      }
    } else {
      onChangeSelectedAgents([...selectedAgentIds, id]);
    }
  };

  const toggleFileAttachment = (fileId: string) => {
    setAttachedFileIds((prev) =>
      prev.includes(fileId)
        ? prev.filter((id) => id !== fileId)
        : [...prev, fileId]
    );
  };

  const handleVoiceToggle = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setVoiceNote(
        'Browser SpeechRecognition API is unavailable in this frame; inserted voice command template.'
      );
      setPrompt((prev) =>
        prev
          ? `${prev} Coordinate all selected agents in parallel and synthesize an executive artifact.`
          : 'Coordinate all selected agents in parallel to review the attached repository files and produce a unified architecture + security report.'
      );
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-US';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
        setVoiceNote('Listening for voice command...');
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results?.[0]?.[0]?.transcript || '';
        if (transcript) {
          setPrompt((prev) => (prev ? `${prev} ${transcript}` : transcript));
          setVoiceNote(`Captured voice command: "${transcript}"`);
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
        setVoiceNote(
          'Microphone permission blocked by sandbox; you can type or select a preset command below.'
        );
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch {
      setIsListening(false);
      setVoiceNote('Voice capture ended.');
    }
  };

  const handleRunSwarm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || selectedAgentIds.length === 0) return;

    setIsExecuting(true);
    setErrorMsg(null);
    try {
      const createdRun = await onExecuteSwarm({
        prompt: prompt.trim(),
        agentIds: selectedAgentIds,
        attachedFileIds,
        synthesize,
        saveAsArtifact,
      });
      setActiveRunId(createdRun.id);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to execute parallel swarm command.');
    } finally {
      setIsExecuting(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  return (
    <div className="space-y-8">
      {/* Header & Dual Orchestration Mode Switch */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <p className="text-xs font-medium text-indigo-600 dark:text-indigo-400 mb-1">
            01. Parallel Multi-Agent Broadcast & Voice Command
          </p>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Swarm Command Studio
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
            Speak or broadcast a single instruction across multiple specialist agents simultaneously, attach hosted repository files, and synthesize a unified deliverable.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
            <button
              type="button"
              className="px-3 py-1.5 text-xs font-medium rounded-md bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs whitespace-nowrap shrink-0 cursor-pointer"
            >
              Parallel Swarm Chat
            </button>
            <button
              type="button"
              onClick={onSwitchToDAGMode}
              className="px-3 py-1.5 text-xs font-medium rounded-md text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Visual DAG Pipeline
            </button>
          </div>
        </div>
      </div>

      {/* Main Command Dispatcher Card */}
      <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-5">
        {/* Step 1: Select Participating Agents */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
              1. Select Parallel Agent Cohort ({selectedAgentIds.length} of{' '}
              {agents.length} active)
            </span>
            <div className="flex items-center gap-3 text-xs">
              <button
                type="button"
                onClick={() => onChangeSelectedAgents(agents.map((a) => a.id))}
                className="text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                Select All Agents
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
            {agents.map((agent) => {
              const isSelected = selectedAgentIds.includes(agent.id);
              return (
                <button
                  key={agent.id}
                  type="button"
                  onClick={() => toggleAgent(agent.id)}
                  className={`flex items-start justify-between p-3 rounded-lg border text-left transition-colors cursor-pointer ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 text-slate-900 dark:text-slate-100'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 text-slate-500 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="min-w-0 pr-2">
                    <div className="text-xs font-semibold truncate">
                      {agent.name}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {agent.role}
                    </div>
                    <div className="text-[11px] font-mono text-indigo-600 dark:text-indigo-400 mt-1">
                      {agent.model}
                    </div>
                  </div>
                  <div
                    className={`w-4 h-4 rounded flex items-center justify-center shrink-0 mt-0.5 ${
                      isSelected
                        ? 'bg-indigo-600 text-white'
                        : 'border border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    {isSelected && <Check className="w-3 h-3" />}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 2: Optional Context Files from Vault */}
        <div>
          <div className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
            2. Attach Hosted Files or GitHub Context (Optional —{' '}
            {attachedFileIds.length} attached)
          </div>
          <div className="flex flex-wrap gap-2">
            {files.slice(0, 6).map((file) => {
              const attached = attachedFileIds.includes(file.id);
              return (
                <button
                  key={file.id}
                  type="button"
                  onClick={() => toggleFileAttachment(file.id)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-lg border transition-colors cursor-pointer ${
                    attached
                      ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/50 text-indigo-900 dark:text-indigo-200'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate max-w-[200px]">{file.path}</span>
                  {attached && <Check className="w-3 h-3 text-indigo-500" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 3: Prompt + Voice Input Form */}
        <form onSubmit={handleRunSwarm} className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-medium text-slate-700 dark:text-slate-300">
              3. Broadcast Command or Speak Instruction
            </label>
            <div className="flex flex-wrap items-center gap-2">
              {PRESET_PROMPTS.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPrompt(preset)}
                  className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                >
                  Preset {idx + 1}
                </button>
              ))}
            </div>
          </div>

          <div className="relative">
            <textarea
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Enter a command to execute across all selected agents in parallel (e.g., 'Review the attached code for security flaws, architectural bottlenecks, and generate a CI deployment workflow')..."
              className="w-full p-3.5 pr-12 text-sm rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
            />
            <button
              type="button"
              onClick={handleVoiceToggle}
              title="Voice Command Input"
              className={`absolute right-3 top-3 p-2 rounded-lg border transition-colors cursor-pointer ${
                isListening
                  ? 'border-red-500 bg-red-50 dark:bg-red-950/60 text-red-600 dark:text-red-400'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:text-indigo-600'
              }`}
            >
              {isListening ? (
                <MicOff className="w-4 h-4" />
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </button>
          </div>

          {voiceNote && (
            <p className="text-xs text-indigo-600 dark:text-indigo-400">
              {voiceNote}
            </p>
          )}
          {errorMsg && (
            <p className="text-xs text-red-600 dark:text-red-400">{errorMsg}</p>
          )}

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
            <div className="flex flex-wrap items-center gap-5 text-xs text-slate-600 dark:text-slate-400">
              <label className="inline-flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={synthesize}
                  onChange={(e) => setSynthesize(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span>Synthesize Coordinator Consensus</span>
              </label>

              <label className="inline-flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={saveAsArtifact}
                  onChange={(e) => setSaveAsArtifact(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span>Auto-Host Output in Artifact Vault</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={isExecuting || !prompt.trim()}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              {isExecuting
                ? `Executing ${selectedAgentIds.length} Agents in Parallel...`
                : `Execute Parallel Swarm (${selectedAgentIds.length} Agents)`}
            </button>
          </div>
        </form>
      </div>

      {/* Execution Results Matrix & Run History */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Sidebar: Swarm Run History */}
        <div className="lg:col-span-3 space-y-3">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-400" />
            Swarm Session History
          </h2>
          <div className="space-y-2">
            {swarmRuns.map((run) => {
              const isCurrent = activeRun?.id === run.id;
              return (
                <button
                  key={run.id}
                  onClick={() => setActiveRunId(run.id)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-colors cursor-pointer ${
                    isCurrent
                      ? 'border-indigo-600 bg-white dark:bg-slate-900'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/40 hover:bg-white dark:hover:bg-slate-900'
                  }`}
                >
                  <div className="text-xs font-medium text-slate-900 dark:text-slate-100 line-clamp-2">
                    {run.prompt}
                  </div>
                  <div className="mt-2 flex items-center gap-1.5 text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                    <span>{run.results.length} agents</span>
                    <span>·</span>
                    <span>
                      {new Date(run.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Main Viewport: Parallel Agent Lanes + Coordinator Synthesis */}
        <div className="lg:col-span-9 space-y-6">
          {isExecuting ? (
            <div className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-slate-900 dark:text-slate-100">
                  Dispatching command to {selectedAgentIds.length} Gemini agents in parallel...
                </span>
                <span className="text-xs font-mono text-indigo-600 dark:text-indigo-400">
                  Promise.all() active
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {selectedAgentIds.map((id) => {
                  const ag = agents.find((a) => a.id === id);
                  return (
                    <div
                      key={id}
                      className="p-4 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2 animate-pulse"
                    >
                      <div className="h-4 w-1/2 bg-slate-200 dark:bg-slate-800 rounded" />
                      <div className="text-xs font-mono text-slate-400">
                        Running {ag?.name || id} ({ag?.model})...
                      </div>
                      <div className="h-20 bg-slate-100 dark:bg-slate-800/60 rounded" />
                    </div>
                  );
                })}
              </div>
            </div>
          ) : activeRun ? (
            <>
              {/* Coordinator Consensus Synthesis Box */}
              {activeRun.synthesis && (
                <div className="p-5 rounded-xl border border-indigo-200 dark:border-indigo-900/70 bg-indigo-50/30 dark:bg-indigo-950/20 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-indigo-200/60 dark:border-indigo-900/50 pb-3">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                        Nexus Coordinator — Unified Consensus Synthesis
                      </h3>
                    </div>

                    <div className="flex items-center gap-2">
                      {activeRun.savedArtifactPath ? (
                        <button
                          onClick={() =>
                            onOpenArtifactInVault(activeRun.savedArtifactPath!)
                          }
                          className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-mono text-indigo-700 dark:text-indigo-300 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 rounded-lg hover:bg-indigo-50 cursor-pointer"
                        >
                          <Archive className="w-3.5 h-3.5" />
                          {activeRun.savedArtifactPath}
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      ) : (
                        <button
                          onClick={() => onSaveRunToVault(activeRun.id)}
                          className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg cursor-pointer"
                        >
                          <Archive className="w-3.5 h-3.5" />
                          Host in Artifact Vault
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed font-sans">
                    {activeRun.synthesis}
                  </div>
                </div>
              )}

              {/* Parallel Agent Lanes */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-slate-400" />
                    Parallel Agent Execution Lanes ({activeRun.results.length})
                  </h3>
                  <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                    Total tokens:{' '}
                    {activeRun.results
                      .reduce((acc, r) => acc + r.tokens, 0)
                      .toLocaleString()}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {activeRun.results.map((res) => (
                    <div
                      key={res.agentId}
                      className="flex flex-col justify-between p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                          <div>
                            <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                              {res.agentName}
                            </h4>
                            <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                              {res.agentRole} ·{' '}
                              <span className="font-mono tabular-nums">
                                {res.latencyMs}ms
                              </span>{' '}
                              ·{' '}
                              <span className="font-mono tabular-nums">
                                {res.tokens} tok
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={() =>
                              handleCopy(
                                `${activeRun.id}-${res.agentId}`,
                                res.content
                              )
                            }
                            title="Copy Agent Output"
                            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg cursor-pointer"
                          >
                            {copiedId === `${activeRun.id}-${res.agentId}` ? (
                              <Check className="w-4 h-4 text-emerald-500" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </button>
                        </div>

                        <div className="mt-3 text-xs text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed max-h-80 overflow-y-auto pr-1">
                          {res.content}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="p-12 text-center rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Select agents above and enter a prompt to run your first parallel Swarm Broadcast.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
