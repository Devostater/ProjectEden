import React, { useState } from 'react';
import {
  Play,
  Plus,
  GitBranch,
  Webhook,
  Archive,
  Cpu,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowRight,
  Trash2,
} from 'lucide-react';
import type { Agent, DAGPipeline, DAGNode, DAGNodeType } from '../types';

interface DAGPipelineViewProps {
  pipelines: DAGPipeline[];
  agents: Agent[];
  onSavePipeline: (pipeline: DAGPipeline) => Promise<DAGPipeline>;
  onExecutePipeline: (
    pipelineId: string,
    customInput?: string
  ) => Promise<DAGPipeline>;
  onOpenArtifactInVault: (path: string) => void;
  onSwitchToSwarmMode: () => void;
}

export const DAGPipelineView: React.FC<DAGPipelineViewProps> = ({
  pipelines,
  agents,
  onSavePipeline,
  onExecutePipeline,
  onOpenArtifactInVault,
  onSwitchToSwarmMode,
}) => {
  const [selectedPipelineId, setSelectedPipelineId] = useState<string>(
    pipelines[0]?.id || ''
  );
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(
    pipelines[0]?.nodes[0]?.id || null
  );
  const [customInput, setCustomInput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [isAddingNode, setIsAddingNode] = useState(false);
  const [newNodeLabel, setNewNodeLabel] = useState('');
  const [newNodeType, setNewNodeType] = useState<DAGNodeType>('agent');
  const [newNodeParentId, setNewNodeParentId] = useState<string>('');

  const activePipeline =
    pipelines.find((p) => p.id === selectedPipelineId) || pipelines[0];

  const selectedNode =
    activePipeline?.nodes.find((n) => n.id === selectedNodeId) ||
    activePipeline?.nodes[0] ||
    null;

  const handleSelectPipeline = (id: string) => {
    setSelectedPipelineId(id);
    const pipe = pipelines.find((p) => p.id === id);
    if (pipe && pipe.nodes.length > 0) {
      setSelectedNodeId(pipe.nodes[0].id);
    }
  };

  const handleRunPipeline = async () => {
    if (!activePipeline || isRunning) return;
    setIsRunning(true);
    try {
      await onExecutePipeline(activePipeline.id, customInput.trim() || undefined);
    } finally {
      setIsRunning(false);
    }
  };

  const handleUpdateSelectedNode = async (patch: Partial<DAGNode>) => {
    if (!activePipeline || !selectedNode) return;
    const updatedNodes = activePipeline.nodes.map((n) =>
      n.id === selectedNode.id ? { ...n, ...patch } : n
    );
    await onSavePipeline({
      ...activePipeline,
      nodes: updatedNodes,
    });
  };

  const handleAddNode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePipeline || !newNodeLabel.trim()) return;

    const maxX = activePipeline.nodes.reduce(
      (max, n) => Math.max(max, n.x),
      100
    );
    const newId = `node-${Date.now().toString().slice(-4)}`;
    const newNode: DAGNode = {
      id: newId,
      label: newNodeLabel.trim(),
      type: newNodeType,
      agentId: newNodeType === 'agent' ? agents[0]?.id : undefined,
      prompt:
        newNodeType === 'agent'
          ? `Analyze the upstream context for ${newNodeLabel.trim()} and output structured recommendations.`
          : undefined,
      repoTarget:
        newNodeType === 'github_fetch'
          ? 'modelcontextprotocol/servers'
          : undefined,
      webhookUrl:
        newNodeType === 'api_webhook' ? 'https://httpbin.org/post' : undefined,
      outputPath:
        newNodeType === 'artifact_save'
          ? `/artifacts/${activePipeline.id}-output.md`
          : undefined,
      status: 'idle',
      x: Math.min(920, maxX + 240),
      y: 150,
    };

    const updatedEdges = [...activePipeline.edges];
    if (newNodeParentId) {
      updatedEdges.push({
        id: `e-${newNodeParentId}-${newId}`,
        source: newNodeParentId,
        target: newId,
      });
    }

    const updated = await onSavePipeline({
      ...activePipeline,
      nodes: [...activePipeline.nodes, newNode],
      edges: updatedEdges,
    });

    setSelectedNodeId(newId);
    setNewNodeLabel('');
    setIsAddingNode(false);
    return updated;
  };

  const handleDeleteNode = async (nodeId: string) => {
    if (!activePipeline || activePipeline.nodes.length <= 1) return;
    const updatedNodes = activePipeline.nodes.filter((n) => n.id !== nodeId);
    const updatedEdges = activePipeline.edges.filter(
      (e) => e.source !== nodeId && e.target !== nodeId
    );
    await onSavePipeline({
      ...activePipeline,
      nodes: updatedNodes,
      edges: updatedEdges,
    });
    setSelectedNodeId(updatedNodes[0]?.id || null);
  };

  const getNodeTypeIcon = (type: DAGNodeType) => {
    switch (type) {
      case 'github_fetch':
        return <GitBranch className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
      case 'api_webhook':
        return <Webhook className="w-4 h-4 text-amber-600 dark:text-amber-400" />;
      case 'artifact_save':
        return <Archive className="w-4 h-4 text-sky-600 dark:text-sky-400" />;
      default:
        return <Cpu className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Section Header + Mode Switch */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <p className="text-xs font-medium text-indigo-600 dark:text-indigo-400 mb-1">
            01. Topological Multi-Agent Workflow Orchestrator
          </p>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Visual DAG Pipeline Studio
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
            Chain GitHub repository ingestion, parallel AI agent stages, webhook triggers, and automated artifact hosting into repeatable pipelines.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
            <button
              type="button"
              onClick={onSwitchToSwarmMode}
              className="px-3 py-1.5 text-xs font-medium rounded-md text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Parallel Swarm Chat
            </button>
            <button
              type="button"
              className="px-3 py-1.5 text-xs font-medium rounded-md bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs whitespace-nowrap shrink-0 cursor-pointer"
            >
              Visual DAG Pipeline
            </button>
          </div>
        </div>
      </div>

      {/* Pipeline Selector & Execution Toolbar */}
      <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          {pipelines.map((pipe) => (
            <button
              key={pipe.id}
              onClick={() => handleSelectPipeline(pipe.id)}
              className={`px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activePipeline?.id === pipe.id
                  ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200'
                  : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {pipe.name}
            </button>
          ))}

          <button
            onClick={() => {
              setNewNodeParentId(
                activePipeline?.nodes[activePipeline.nodes.length - 1]?.id || ''
              );
              setIsAddingNode(true);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 border border-dashed border-slate-300 dark:border-slate-700 rounded-lg hover:border-indigo-500 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Add DAG Stage
          </button>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
          <input
            type="text"
            value={customInput}
            onChange={(e) => setCustomInput(e.target.value)}
            placeholder="Optional runtime parameter / context..."
            className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 min-w-[240px]"
          />

          <button
            onClick={handleRunPipeline}
            disabled={isRunning}
            className="inline-flex items-center justify-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5" />
            {isRunning ? 'Executing DAG Wave...' : 'Execute Pipeline'}
          </button>
        </div>
      </div>

      {activePipeline && (
        <>
          {/* Interactive Visual DAG Canvas */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950 overflow-x-auto p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  {activePipeline.name}
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {activePipeline.description}
                </p>
              </div>
              <div className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                {activePipeline.nodes.length} stages ·{' '}
                {activePipeline.edges.length} edges
              </div>
            </div>

            <div className="relative min-w-[1140px] h-[360px] rounded-lg border border-slate-200/80 dark:border-slate-800/80 bg-white dark:bg-slate-900/90 overflow-hidden">
              {/* SVG Edges */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none">
                <defs>
                  <marker
                    id="dag-arrow"
                    markerWidth="8"
                    markerHeight="8"
                    refX="6"
                    refY="4"
                    orient="auto"
                  >
                    <path
                      d="M0,0 L8,4 L0,8 Z"
                      className="fill-slate-400 dark:fill-slate-600"
                    />
                  </marker>
                </defs>
                {activePipeline.edges.map((edge) => {
                  const sourceNode = activePipeline.nodes.find(
                    (n) => n.id === edge.source
                  );
                  const targetNode = activePipeline.nodes.find(
                    (n) => n.id === edge.target
                  );
                  if (!sourceNode || !targetNode) return null;

                  const x1 = sourceNode.x + 210;
                  const y1 = sourceNode.y + 42;
                  const x2 = targetNode.x - 4;
                  const y2 = targetNode.y + 42;
                  const midX = (x1 + x2) / 2;

                  return (
                    <path
                      key={edge.id}
                      d={`M ${x1} ${y1} C ${midX} ${y1}, ${midX} ${y2}, ${x2} ${y2}`}
                      fill="none"
                      strokeWidth="2"
                      markerEnd="url(#dag-arrow)"
                      className={
                        isRunning
                          ? 'stroke-indigo-500'
                          : 'stroke-slate-300 dark:stroke-slate-700'
                      }
                    />
                  );
                })}
              </svg>

              {/* DAG Stage Nodes */}
              {activePipeline.nodes.map((node) => {
                const isSelected = selectedNode?.id === node.id;
                const assignedAgent = agents.find((a) => a.id === node.agentId);

                return (
                  <div
                    key={node.id}
                    onClick={() => setSelectedNodeId(node.id)}
                    style={{ left: `${node.x}px`, top: `${node.y}px` }}
                    className={`absolute w-[210px] p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/40 dark:bg-indigo-950/40 shadow-sm'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        {getNodeTypeIcon(node.type)}
                        <span className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                          {node.label}
                        </span>
                      </div>

                      {node.status === 'completed' && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      )}
                      {node.status === 'error' && (
                        <AlertCircle className="w-3.5 h-3.5 text-red-500 shrink-0" />
                      )}
                      {node.status === 'running' && (
                        <Clock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                      )}
                    </div>

                    <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {node.type === 'agent'
                        ? assignedAgent
                          ? `${assignedAgent.name} · ${assignedAgent.model}`
                          : 'AI Agent Stage'
                        : node.type === 'github_fetch'
                          ? `repo: ${node.repoTarget || 'GitHub'}`
                          : node.type === 'artifact_save'
                            ? `vault: ${node.outputPath || '/artifacts'}`
                            : `webhook: ${node.webhookUrl || 'POST'}`}
                    </div>

                    <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                      <span>
                        {node.status === 'completed'
                          ? 'Completed'
                          : node.status === 'running'
                            ? 'Running'
                            : node.status === 'error'
                              ? 'Failed'
                              : 'Ready'}
                      </span>
                      {node.latencyMs !== undefined && (
                        <span>{node.latencyMs}ms</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected Node Inspector & Output Console */}
          {selectedNode && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left: Node Configuration */}
              <div className="lg:col-span-5 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                      Stage Configuration: {selectedNode.label}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Node ID: <span className="font-mono">{selectedNode.id}</span> · Type:{' '}
                      <span className="font-mono">{selectedNode.type}</span>
                    </p>
                  </div>
                  {activePipeline.nodes.length > 1 && (
                    <button
                      onClick={() => handleDeleteNode(selectedNode.id)}
                      title="Delete Stage"
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Stage Label
                  </label>
                  <input
                    type="text"
                    value={selectedNode.label}
                    onChange={(e) =>
                      handleUpdateSelectedNode({ label: e.target.value })
                    }
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                  />
                </div>

                {selectedNode.type === 'agent' && (
                  <>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Assigned AI Agent
                      </label>
                      <select
                        value={selectedNode.agentId || agents[0]?.id}
                        onChange={(e) =>
                          handleUpdateSelectedNode({ agentId: e.target.value })
                        }
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      >
                        {agents.map((ag) => (
                          <option key={ag.id} value={ag.id}>
                            {ag.name} ({ag.role} · {ag.model})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Stage Instruction (Receives Upstream Outputs Automatically)
                      </label>
                      <textarea
                        rows={4}
                        value={selectedNode.prompt || ''}
                        onChange={(e) =>
                          handleUpdateSelectedNode({ prompt: e.target.value })
                        }
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </>
                )}

                {selectedNode.type === 'github_fetch' && (
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Target Public GitHub Repository (owner/repo)
                    </label>
                    <input
                      type="text"
                      value={selectedNode.repoTarget || ''}
                      onChange={(e) =>
                        handleUpdateSelectedNode({ repoTarget: e.target.value })
                      }
                      placeholder="modelcontextprotocol/servers"
                      className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                )}

                {selectedNode.type === 'api_webhook' && (
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Target Webhook REST URL (POST)
                    </label>
                    <input
                      type="url"
                      value={selectedNode.webhookUrl || ''}
                      onChange={(e) =>
                        handleUpdateSelectedNode({ webhookUrl: e.target.value })
                      }
                      placeholder="https://httpbin.org/post"
                      className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                )}

                {selectedNode.type === 'artifact_save' && (
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Destination Path in Artifact Vault
                    </label>
                    <input
                      type="text"
                      value={selectedNode.outputPath || ''}
                      onChange={(e) =>
                        handleUpdateSelectedNode({ outputPath: e.target.value })
                      }
                      placeholder="/artifacts/pipeline-output.md"
                      className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                )}
              </div>

              {/* Right: Stage Execution Output */}
              <div className="lg:col-span-7 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                    <div>
                      <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                        Stage Execution Output — {selectedNode.label}
                      </h3>
                      <p className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                        Status: {selectedNode.status}
                        {selectedNode.latencyMs !== undefined &&
                          ` · ${selectedNode.latencyMs}ms`}
                        {selectedNode.tokens !== undefined &&
                          selectedNode.tokens > 0 &&
                          ` · ${selectedNode.tokens} tokens`}
                      </p>
                    </div>

                    {selectedNode.type === 'artifact_save' &&
                      selectedNode.outputPath && (
                        <button
                          onClick={() =>
                            onOpenArtifactInVault(selectedNode.outputPath!)
                          }
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 rounded-lg hover:bg-indigo-100 cursor-pointer"
                        >
                          Open in File Vault
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      )}
                  </div>

                  <div className="mt-4 p-4 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200/70 dark:border-slate-800 font-mono text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed min-h-[200px] max-h-[340px] overflow-y-auto">
                    {selectedNode.lastOutput ||
                      'No execution output yet for this stage. Click "Execute Pipeline" above to run all topological stages.'}
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* Add DAG Stage Modal */}
      {isAddingNode && activePipeline && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
            <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              Add Stage to {activePipeline.name}
            </h3>

            <form onSubmit={handleAddNode} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Stage Name
                </label>
                <input
                  type="text"
                  required
                  value={newNodeLabel}
                  onChange={(e) => setNewNodeLabel(e.target.value)}
                  placeholder="e.g. Performance Regression Audit"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Stage Type
                </label>
                <select
                  value={newNodeType}
                  onChange={(e) => setNewNodeType(e.target.value as DAGNodeType)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                >
                  <option value="agent">AI Agent Reasoning Step</option>
                  <option value="github_fetch">GitHub Repository Ingest</option>
                  <option value="api_webhook">Webhook REST Dispatch</option>
                  <option value="artifact_save">Save Output to Artifact Vault</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Connect Upstream Stage (Dependency)
                </label>
                <select
                  value={newNodeParentId}
                  onChange={(e) => setNewNodeParentId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                >
                  <option value="">None (Root Stage)</option>
                  {activePipeline.nodes.map((n) => (
                    <option key={n.id} value={n.id}>
                      {n.label} ({n.id})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddingNode(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg cursor-pointer"
                >
                  Add Stage to DAG
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
