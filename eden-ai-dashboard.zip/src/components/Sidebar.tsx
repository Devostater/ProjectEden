import React from 'react';
import {
  Sparkles,
  LayoutDashboard,
  Cpu,
  Layers,
  GitBranch,
  FolderGit2,
  Activity,
  Zap,
  CheckCircle2,
} from 'lucide-react';
import type { Agent, DAGPipeline, HostedFile } from '../types/index.ts';

export type AppTab = 'eden' | 'dashboard' | 'my-ai' | 'swarm' | 'pipelines' | 'files';

interface SidebarProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  agents: Agent[];
  pipelines: DAGPipeline[];
  files: HostedFile[];
  totalTokens: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  agents,
  pipelines,
  files,
  totalTokens,
}) => {
  const quotaLimit = 500000;
  const quotaPercent = Math.min(100, Math.round((totalTokens / quotaLimit) * 100));

  const navItems = [
    {
      id: 'eden' as AppTab,
      label: 'Eden Sanctuary',
      icon: Sparkles,
      badge: 'Calm Space',
      badgeColor: 'text-pink-400 bg-pink-500/10 border border-pink-500/20',
    },
    {
      id: 'dashboard' as AppTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: 'Metrics & Bars',
      badgeColor: 'text-indigo-400 bg-indigo-500/10',
    },
    {
      id: 'my-ai' as AppTab,
      label: 'My AI',
      icon: Cpu,
      badge: `${agents.length} Connected`,
      badgeColor: 'text-emerald-400 bg-emerald-500/10',
    },
    {
      id: 'swarm' as AppTab,
      label: 'Swarm Studio',
      icon: Layers,
      badge: 'Parallel',
      badgeColor: 'text-purple-400 bg-purple-500/10',
    },
    {
      id: 'pipelines' as AppTab,
      label: 'DAG Pipelines',
      icon: GitBranch,
      badge: `${pipelines.length}`,
      badgeColor: 'text-amber-400 bg-amber-500/10',
    },
    {
      id: 'files' as AppTab,
      label: 'Files & GitHub',
      icon: FolderGit2,
      badge: `${files.length}`,
      badgeColor: 'text-sky-400 bg-sky-500/10',
    },
  ];

  return (
    <aside className="w-64 shrink-0 h-screen sticky top-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-r border-slate-200 dark:border-slate-800 flex flex-col justify-between overflow-y-auto select-none z-40 transition-colors">
      <div>
        {/* Brand Lockup: EDEN AI */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div
            onClick={() => setActiveTab('eden')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-400 flex items-center justify-center text-white shadow-sm shadow-indigo-500/30 group-hover:scale-105 transition-transform">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-sm tracking-tight text-slate-900 dark:text-white block leading-none font-display">
                EDEN AI
              </span>
              <span className="text-3xs text-slate-400 dark:text-slate-500 font-mono mt-0.5 block">
                Calm Space Sanctuary
              </span>
            </div>
          </div>
          <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/50" title="Eden Sanctuary Harmonious" />
        </div>

        {/* Navigation Tabs (Vertical Scrollable List) */}
        <div className="p-3 space-y-1">
          <div className="px-3 py-1.5 text-3xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 font-mono">
            Navigation Pathways
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all group ${
                  isActive
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-sm shadow-indigo-600/30 font-semibold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-200'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>
                <span
                  className={`text-3xs px-2 py-0.5 rounded-full font-mono shrink-0 tabular-nums ${
                    isActive ? 'bg-white/20 text-white' : item.badgeColor
                  }`}
                >
                  {item.badge}
                </span>
              </button>
            );
          })}
        </div>

        {/* Connected AI Quick Roster in Sidebar */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800/80">
          <div className="flex items-center justify-between px-3 py-1.5">
            <span className="text-3xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 font-mono">
              Cosmic Fleet ({agents.length})
            </span>
            <button
              onClick={() => setActiveTab('my-ai')}
              className="text-3xs text-indigo-500 hover:underline font-mono"
            >
              All AI →
            </button>
          </div>

          <div className="space-y-1 mt-1">
            {agents.slice(0, 6).map((agent) => (
              <div
                key={agent.id}
                onClick={() => setActiveTab('my-ai')}
                className="flex items-center justify-between px-3 py-1.5 rounded-lg text-xs hover:bg-slate-100 dark:hover:bg-slate-800/50 cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-2 truncate pr-2">
                  <span
                    className="w-2 h-2 rounded-full shrink-0 shadow-xs"
                    style={{ backgroundColor: agent.color }}
                  />
                  <span className="text-slate-800 dark:text-slate-200 truncate font-medium text-xs">
                    {agent.name.split(' ')[0]}
                  </span>
                </div>
                <span className="text-3xs font-mono text-slate-400 shrink-0">
                  {agent.avatar || agent.name.slice(0, 2).toUpperCase()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sidebar Footer: Monthly Quota & Runtime Health */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/40 space-y-3">
        <div>
          <div className="flex items-center justify-between text-3xs mb-1 font-mono">
            <span className="text-slate-500 dark:text-slate-400">Eden Quota</span>
            <span className="font-semibold text-slate-900 dark:text-white tabular-nums">
              {quotaPercent}%
            </span>
          </div>
          <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-full transition-all duration-300"
              style={{ width: `${quotaPercent}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-3xs font-mono text-slate-400 mt-1">
            <span>{(totalTokens / 1000).toFixed(0)}k</span>
            <span>{(quotaLimit / 1000).toFixed(0)}k cap</span>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center justify-between text-3xs text-slate-500 dark:text-slate-400 font-mono">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>Calm Space Active</span>
          </span>
          <span>v3.0</span>
        </div>
      </div>
    </aside>
  );
};
