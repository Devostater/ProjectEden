import React from 'react';
import { Sun, Moon, Play, Plus, Zap, Activity } from 'lucide-react';
import type { AppTab } from './Sidebar.tsx';

interface HeaderProps {
  activeTab: AppTab;
  onQuickRun: () => void;
  onDeployAI: () => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  totalTokens: number;
  agentCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onQuickRun,
  onDeployAI,
  darkMode,
  setDarkMode,
  totalTokens,
  agentCount,
}) => {
  const getTabTitle = (tab: AppTab) => {
    switch (tab) {
      case 'eden':
        return 'Eden Sanctuary · Calm Space';
      case 'dashboard':
        return 'Dashboard & Telemetry';
      case 'my-ai':
        return 'My AI & Game Dev Engines';
      case 'swarm':
        return 'Swarm Command Studio';
      case 'pipelines':
        return 'Visual DAG Pipeline Studio';
      case 'files':
        return 'Files & GitHub Artifact Vault';
      default:
        return 'AI Command Center';
    }
  };

  return (
    <header className="sticky top-0 z-20 flex items-center justify-between gap-4 px-6 py-3 border-b bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-slate-200 dark:border-slate-800 transition-colors">
      {/* Zone 1: Breadcrumb / Active Context */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-mono text-slate-400 dark:text-slate-500">
          NexusFlow /
        </span>
        <span className="text-sm font-bold text-slate-900 dark:text-white">
          {getTabTitle(activeTab)}
        </span>
      </div>

      {/* Zone 2: Telemetry status badge */}
      <div className="hidden md:flex items-center gap-3 text-xs font-mono text-slate-500 dark:text-slate-400">
        <span className="inline-flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-emerald-500" />
          <span className="text-slate-700 dark:text-slate-300 font-medium">
            {agentCount} AI Services Connected
          </span>
        </span>
        <span>·</span>
        <span className="tabular-nums">{(totalTokens / 1000).toFixed(1)}k tokens processed</span>
      </div>

      {/* Zone 3: Topbar Action Buttons (Preserved as requested) */}
      <div className="flex items-center gap-2.5 shrink-0">
        <button
          onClick={onDeployAI}
          className="hidden sm:inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Connect AI</span>
        </button>

        <button
          onClick={() => setDarkMode(!darkMode)}
          aria-label="Toggle theme"
          className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        <button
          onClick={onQuickRun}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
        >
          <Play className="w-3 h-3 fill-current" />
          <span>Launch Swarm</span>
        </button>
      </div>
    </header>
  );
};
