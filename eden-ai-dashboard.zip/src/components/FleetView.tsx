import React, { useState } from 'react';
import type { Agent, UsageMetric, TelemetrySummary } from '../types/index.ts';
import {
  Layers,
  ShieldCheck,
  Terminal,
  GitPullRequest,
  Cpu,
  Plus,
  Edit3,
  Trash2,
  Play,
  Activity,
  Zap,
  Clock,
  Coins,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Search,
} from 'lucide-react';

interface FleetViewProps {
  agents: Agent[];
  usageSummary: TelemetrySummary;
  onSaveAgent: (agent: Partial<Agent>) => Promise<void>;
  onDeleteAgent: (id: string) => Promise<void>;
  onSelectAgentForSwarm: (agentId: string) => void;
}

export const FleetView: React.FC<FleetViewProps> = ({
  agents,
  usageSummary,
  onSaveAgent,
  onDeleteAgent,
  onSelectAgentForSwarm,
}) => {
  const [selectedAgentForEdit, setSelectedAgentForEdit] = useState<Agent | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [searchFilter, setSearchFilter] = useState('');
  const [logFilter, setLogFilter] = useState('all');

  // Form state for creating/editing
  const [formName, setFormName] = useState('');
  const [formRole, setFormRole] = useState('');
  const [formModel, setFormModel] = useState<'gemini-3.8-flash' | 'gemini-3.1-flash-lite'>('gemini-3.8-flash');
  const [formInstruction, setFormInstruction] = useState('');
  const [formColor, setFormColor] = useState('#6366F1');
  const [formWebhook, setFormWebhook] = useState('');
  const [formGithubRepo, setFormGithubRepo] = useState('');
  const [formTools, setFormTools] = useState<string[]>(['artifact_vault']);

  const openEditDrawer = (agent?: Agent) => {
    if (agent) {
      setSelectedAgentForEdit(agent);
      setFormName(agent.name);
      setFormRole(agent.role);
      setFormModel(agent.model);
      setFormInstruction(agent.systemInstruction);
      setFormColor(agent.color);
      setFormWebhook(agent.webhookUrl || '');
      setFormGithubRepo(agent.githubRepo || '');
      setFormTools(agent.connectedTools || ['artifact_vault']);
    } else {
      setSelectedAgentForEdit(null);
      setFormName('');
      setFormRole('');
      setFormModel('gemini-3.8-flash');
      setFormInstruction('You are an expert AI agent specialized in your domain.');
      setFormColor('#6366F1');
      setFormWebhook('');
      setFormGithubRepo('');
      setFormTools(['artifact_vault']);
    }
    setIsDrawerOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveAgent({
      id: selectedAgentForEdit?.id,
      name: formName,
      role: formRole,
      model: formModel,
      systemInstruction: formInstruction,
      color: formColor,
      webhookUrl: formWebhook,
      githubRepo: formGithubRepo,
      connectedTools: formTools,
    });
    setIsDrawerOpen(false);
  };

  const getAgentIcon = (name: string, role: string) => {
    const text = `${name} ${role}`.toLowerCase();
    if (text.includes('security') || text.includes('audit')) return <ShieldCheck className="w-5 h-5" />;
    if (text.includes('code') || text.includes('engineer')) return <Terminal className="w-5 h-5" />;
    if (text.includes('github') || text.includes('pr') || text.includes('ops'))
      return <GitPullRequest className="w-5 h-5" />;
    if (text.includes('api') || text.includes('webhook') || text.includes('weaver'))
      return <Cpu className="w-5 h-5" />;
    return <Layers className="w-5 h-5" />;
  };

  const filteredAgents = agents.filter(
    (a) =>
      a.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
      a.role.toLowerCase().includes(searchFilter.toLowerCase()) ||
      a.model.toLowerCase().includes(searchFilter.toLowerCase())
  );

  const filteredLogs = usageSummary.recentLogs.filter((log) => {
    if (logFilter === 'all') return true;
    return log.operation.toLowerCase().includes(logFilter.toLowerCase());
  });

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      {/* View Title & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Fleet Roster & Telemetry
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Real-time status, token consumption, latency benchmarks, and configurations for your AI agent fleet.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => openEditDrawer()}
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 dark:hover:bg-indigo-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Deploy Agent</span>
          </button>
        </div>
      </div>

      {/* KPI Metric Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Tokens</span>
            <Zap className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-2">
            {usageSummary.totalTokens.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 mt-1">Across all agent executions</div>
        </div>

        <div className="p-4 rounded-xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Executions</span>
            <Activity className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-2">
            {usageSummary.totalRuns.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 mt-1">Swarm broadcasts & DAG steps</div>
        </div>

        <div className="p-4 rounded-xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Average Latency</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-2">
            {usageSummary.avgLatencyMs}
            <span className="text-sm font-normal text-slate-400 ml-1">ms</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">End-to-end response time</div>
        </div>

        <div className="p-4 rounded-xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Est. API Expense</span>
            <Coins className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-2">
            ${usageSummary.estimatedCost.toFixed(4)}
          </div>
          <div className="text-xs text-slate-400 mt-1">Flash tier baseline tier</div>
        </div>
      </div>

      {/* Fleet Grid */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h2 className="text-base font-semibold text-slate-900 dark:text-white">Active Agent Roster</h2>
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search agents or roles..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAgents.map((agent) => (
            <div
              key={agent.id}
              className="p-5 rounded-xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 flex flex-col justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
            >
              <div>
                {/* Agent Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center text-white shrink-0"
                      style={{ backgroundColor: agent.color }}
                    >
                      {getAgentIcon(agent.name, agent.role)}
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-slate-900 dark:text-white leading-tight">
                        {agent.name}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{agent.role}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => openEditDrawer(agent)}
                      title="Edit agent settings"
                      className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    {agents.length > 1 && (
                      <button
                        onClick={() => onDeleteAgent(agent.id)}
                        title="Delete agent"
                        className="p-1.5 text-slate-400 hover:text-red-500 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Unboxed Metadata (Zero-Pill discipline) */}
                <div className="flex items-center gap-2 text-xs font-mono text-slate-500 dark:text-slate-400 mt-4">
                  <span>{agent.model}</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">{(agent.totalTokens / 1000).toFixed(1)}k tokens</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">{agent.avgLatencyMs}ms</span>
                </div>

                {/* System Prompt snippet */}
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-3 line-clamp-2 leading-relaxed bg-slate-50 dark:bg-slate-950/60 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800/80">
                  {agent.systemInstruction}
                </p>

                {/* Connected Tools & GitHub Links */}
                <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                  {agent.githubRepo && (
                    <span className="inline-flex items-center gap-1 hover:text-indigo-500 transition-colors">
                      <GitPullRequest className="w-3 h-3 text-slate-400" />
                      <span>{agent.githubRepo}</span>
                    </span>
                  )}
                  {agent.webhookUrl && (
                    <span className="inline-flex items-center gap-1">
                      <Cpu className="w-3 h-3 text-slate-400" />
                      <span>Webhook configured</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-4 mt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs text-slate-400 font-mono tabular-nums">{agent.totalRuns} runs recorded</span>
                <button
                  onClick={() => onSelectAgentForSwarm(agent.id)}
                  className="px-3 py-1.5 text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 rounded-md transition-colors flex items-center gap-1"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>Command in Swarm</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Usage Telemetry Ledger */}
      <div className="space-y-4 pt-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-900 dark:text-white">Execution Telemetry Ledger</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Live audit of individual agent invocations, token payloads, and latencies.
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
            <button
              onClick={() => setLogFilter('all')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                logFilter === 'all'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              All Runs
            </button>
            <button
              onClick={() => setLogFilter('Swarm')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                logFilter === 'Swarm'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Swarm
            </button>
            <button
              onClick={() => setLogFilter('DAG')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                logFilter === 'DAG'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              DAG Steps
            </button>
          </div>
        </div>

        <div className="rounded-xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-950/60 text-slate-500 dark:text-slate-400 font-medium border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Agent</th>
                  <th className="py-3 px-4">Operation</th>
                  <th className="py-3 px-4 text-right">Tokens</th>
                  <th className="py-3 px-4 text-right">Latency</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {filteredLogs.slice(0, 10).map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-500 dark:text-slate-400 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                      })}
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-900 dark:text-white whitespace-nowrap">
                      {log.agentName}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{log.operation}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right text-slate-900 dark:text-white">
                      {log.tokens.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right text-slate-600 dark:text-slate-300">
                      {log.latencyMs}ms
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Completed</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Slide-over Drawer / Modal for Agent Configuration */}
      {isDrawerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="w-full max-w-xl rounded-2xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {selectedAgentForEdit ? `Configure ${selectedAgentForEdit.name}` : 'Deploy New AI Agent'}
              </h2>
              <button
                onClick={() => setIsDrawerOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm font-semibold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Agent Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g., Nexus Architect"
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Specialist Role
                  </label>
                  <input
                    type="text"
                    required
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value)}
                    placeholder="e.g., Cloud & Systems Architect"
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Model Architecture
                  </label>
                  <select
                    value={formModel}
                    onChange={(e) => setFormModel(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="gemini-3.8-flash">gemini-3.8-flash (Standard & Complex Reasoning)</option>
                    <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Ultra Fast & Lightweight)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Accent Color
                  </label>
                  <div className="flex items-center gap-2">
                    {['#6366F1', '#10B981', '#DC2626', '#F59E0B', '#8B5CF6', '#06B6D4'].map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setFormColor(c)}
                        style={{ backgroundColor: c }}
                        className={`w-6 h-6 rounded-full transition-transform ${
                          formColor === c ? 'ring-2 ring-offset-2 ring-indigo-500 scale-110' : 'opacity-80'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  System Instruction / Personality
                </label>
                <textarea
                  required
                  rows={4}
                  value={formInstruction}
                  onChange={(e) => setFormInstruction(e.target.value)}
                  placeholder="Define the agent's responsibilities, tone, and domain expertise..."
                  className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    GitHub Target Repo (optional)
                  </label>
                  <input
                    type="text"
                    value={formGithubRepo}
                    onChange={(e) => setFormGithubRepo(e.target.value)}
                    placeholder="e.g., owner/repo"
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Custom Webhook URL (optional)
                  </label>
                  <input
                    type="url"
                    value={formWebhook}
                    onChange={(e) => setFormWebhook(e.target.value)}
                    placeholder="https://api.external.com/webhook"
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsDrawerOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm transition-colors"
                >
                  {selectedAgentForEdit ? 'Save Changes' : 'Deploy Agent'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
