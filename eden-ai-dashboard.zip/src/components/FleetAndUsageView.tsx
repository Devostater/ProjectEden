import React, { useState, useMemo } from 'react';
import {
  Plus,
  Sliders,
  Play,
  Search,
  Trash2,
  GitBranch,
  Webhook,
  Check,
  X,
  ArrowUpRight,
  RefreshCw,
} from 'lucide-react';
import type { Agent, TelemetrySummary, UsageMetric } from '../types';

interface FleetAndUsageViewProps {
  agents: Agent[];
  telemetry: TelemetrySummary;
  onSaveAgent: (agent: Partial<Agent>) => Promise<void>;
  onDeleteAgent: (id: string) => Promise<void>;
  onLaunchInSwarm: (agentIds: string[]) => void;
  onRefresh: () => void;
}

const AVAILABLE_TOOLS = [
  { id: 'github_repo', label: 'GitHub Repo Inspector' },
  { id: 'artifact_vault', label: 'Artifact Vault Read/Write' },
  { id: 'webhook_dispatch', label: 'Webhook REST Dispatcher' },
  { id: 'code_runner', label: 'Static AST & Type Checker' },
  { id: 'cve_scanner', label: 'Security & OWASP Auditor' },
  { id: 'swarm_router', label: 'Swarm Consensus Router' },
];

export const FleetAndUsageView: React.FC<FleetAndUsageViewProps> = ({
  agents,
  telemetry,
  onSaveAgent,
  onDeleteAgent,
  onLaunchInSwarm,
  onRefresh,
}) => {
  const [editingAgent, setEditingAgent] = useState<Partial<Agent> | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [logFilter, setLogFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredLogs = useMemo(() => {
    return telemetry.recentLogs.filter((log: UsageMetric) => {
      const matchesType = logFilter === 'ALL' || log.operation === logFilter;
      const matchesSearch =
        !searchQuery.trim() ||
        log.agentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        log.operation.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesType && matchesSearch;
    });
  }, [telemetry.recentLogs, logFilter, searchQuery]);

  const handleOpenNewAgent = () => {
    setEditingAgent({
      name: '',
      role: '',
      model: 'gemini-3.8-flash',
      systemInstruction: '',
      color: 'indigo',
      connectedTools: ['artifact_vault', 'github_repo'],
      githubRepo: '',
      webhookUrl: '',
    });
  };

  const handleToggleTool = (toolId: string) => {
    if (!editingAgent) return;
    const current = editingAgent.connectedTools || [];
    const updated = current.includes(toolId)
      ? current.filter((t) => t !== toolId)
      : [...current, toolId];
    setEditingAgent({ ...editingAgent, connectedTools: updated });
  };

  const handleSubmitAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAgent?.name || !editingAgent?.role || !editingAgent?.systemInstruction) {
      return;
    }
    setIsSaving(true);
    try {
      await onSaveAgent(editingAgent);
      setEditingAgent(null);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Section Header + Primary Actions */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <p className="text-xs font-medium text-indigo-600 dark:text-indigo-400 mb-1">
            01. Agent Fleet & Telemetry
          </p>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Command Fleet & Usage Ledger
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
            Monitor token consumption, execution latency, and external GitHub or webhook connectors across your specialized AI agents.
          </p>
        </div>
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={onRefresh}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh Telemetry
          </button>
          <button
            onClick={() => onLaunchInSwarm(agents.map((a) => a.id))}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            Broadcast to All ({agents.length})
          </button>
          <button
            onClick={handleOpenNewAgent}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Register Agent
          </button>
        </div>
      </div>

      {/* 4-Column Full-Width KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 border border-slate-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 divide-y sm:divide-y-0 sm:divide-x divide-slate-200 dark:divide-slate-800">
        <div className="p-5">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            Total Token Volume
          </div>
          <div className="mt-2 text-2xl font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {telemetry.totalTokens.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Across {agents.length} configured agents · Input + Output
          </div>
        </div>

        <div className="p-5">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            Coordinated Agent Runs
          </div>
          <div className="mt-2 text-2xl font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {telemetry.totalRuns.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Swarm broadcasts · DAG stages · Synthesis
          </div>
        </div>

        <div className="p-5">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            Mean Execution Latency
          </div>
          <div className="mt-2 text-2xl font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {telemetry.avgLatencyMs.toLocaleString()} ms
          </div>
          <div className="mt-1 text-xs text-emerald-600 dark:text-emerald-400">
            Nominal response time · Parallel dispatch active
          </div>
        </div>

        <div className="p-5">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            Estimated Compute Usage
          </div>
          <div className="mt-2 text-2xl font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            ${telemetry.estimatedCost.toFixed(4)}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Gemini 3.8 Flash & 3.1 Flash Lite pool
          </div>
        </div>
      </div>

      {/* Registered Agent Roster */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
              02. Active Agent Roster & Connectors
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Select any agent to tune its system prompt, model tier, GitHub repository binding, or webhook endpoint.
            </p>
          </div>
          <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
            {agents.length} agents registered
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {agents.map((agent) => {
            const sharePct =
              telemetry.totalTokens > 0
                ? Math.min(
                    100,
                    Math.round((agent.totalTokens / telemetry.totalTokens) * 100)
                  )
                : 0;

            return (
              <div
                key={agent.id}
                className="flex flex-col justify-between p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
              >
                <div>
                  {/* Top Row: Avatar, Name, Role & Edit */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center font-mono text-xs font-semibold text-slate-800 dark:text-slate-200 shrink-0">
                        {agent.avatar}
                      </div>
                      <div className="min-w-0">
                        <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 truncate">
                          {agent.name}
                        </h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {agent.role}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => setEditingAgent(agent)}
                        title="Configure Agent"
                        className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        <Sliders className="w-4 h-4" />
                      </button>
                      {agents.length > 1 && (
                        <button
                          onClick={() => onDeleteAgent(agent.id)}
                          title="Remove Agent"
                          className="p-2 text-slate-400 hover:text-red-600 dark:hover:text-red-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Unboxed Metadata Line (Zero-Pill Compliance) */}
                  <div className="mt-3 flex flex-wrap items-center gap-1.5 text-xs font-mono text-slate-500 dark:text-slate-400">
                    <span className="text-indigo-600 dark:text-indigo-400 font-medium">
                      {agent.model}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">
                      {agent.totalRuns} runs
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">
                      {agent.avgLatencyMs}ms avg
                    </span>
                  </div>

                  {/* System Instruction Preview */}
                  <p className="mt-3 text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
                    {agent.systemInstruction}
                  </p>

                  {/* Connected GitHub / Webhook & Tools metadata */}
                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 space-y-1.5 text-xs text-slate-500 dark:text-slate-400">
                    {agent.githubRepo && (
                      <div className="flex items-center gap-1.5 truncate">
                        <GitBranch className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="font-mono truncate">
                          github.com/{agent.githubRepo}
                        </span>
                      </div>
                    )}
                    {agent.webhookUrl && (
                      <div className="flex items-center gap-1.5 truncate">
                        <Webhook className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="font-mono truncate">
                          {agent.webhookUrl}
                        </span>
                      </div>
                    )}
                    <div className="text-slate-400 dark:text-slate-500 truncate">
                      Tools: {agent.connectedTools.join(' / ')}
                    </div>
                  </div>
                </div>

                {/* Bottom Usage Bar & Quick Dispatch */}
                <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800/80">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-slate-500 dark:text-slate-400">
                      Token share ({sharePct}%)
                    </span>
                    <span className="font-mono tabular-nums font-medium text-slate-800 dark:text-slate-200">
                      {agent.totalTokens.toLocaleString()} tok
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-600 dark:bg-indigo-500 rounded-full"
                      style={{ width: `${Math.max(4, sharePct)}%` }}
                    />
                  </div>

                  <div className="mt-3 flex items-center justify-between">
                    <button
                      onClick={() => setEditingAgent(agent)}
                      className="text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 transition-colors cursor-pointer"
                    >
                      Edit Prompt & Tools
                    </button>
                    <button
                      onClick={() => onLaunchInSwarm([agent.id])}
                      className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 transition-colors cursor-pointer"
                    >
                      Run Command
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* High-Density Usage Telemetry Ledger */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
              03. Execution & Token Usage Ledger
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Real-time audit log of every Swarm broadcast, DAG pipeline stage, and coordinator synthesis call.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Interactive Segmented Filter */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
              {['ALL', 'Swarm Broadcast', 'DAG Step', 'Consensus Synthesis'].map(
                (op) => (
                  <button
                    key={op}
                    onClick={() => setLogFilter(op)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      logFilter === op
                        ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                    }`}
                  >
                    {op === 'ALL' ? 'All Events' : op}
                  </button>
                )
              )}
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter by agent..."
                className="pl-8 pr-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        <div className="border border-slate-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400 bg-slate-50/60 dark:bg-slate-900/50">
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Agent Name</th>
                  <th className="py-3 px-4">Operation Mode</th>
                  <th className="py-3 px-4">State</th>
                  <th className="py-3 px-4 text-right">Tokens Used</th>
                  <th className="py-3 px-4 text-right">Latency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-xs">
                {filteredLogs.length === 0 ? (
                  <tr>
                    <td
                      colSpan={6}
                      className="py-8 text-center text-slate-500 dark:text-slate-400"
                    >
                      No matching execution logs found. Trigger a Swarm Broadcast or DAG Pipeline run to populate telemetry.
                    </td>
                  </tr>
                ) : (
                  filteredLogs.map((log) => (
                    <tr
                      key={log.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-2.5 px-4 font-mono tabular-nums text-slate-500 dark:text-slate-400 whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                          second: '2-digit',
                        })}
                      </td>
                      <td className="py-2.5 px-4 font-medium text-slate-900 dark:text-slate-100 whitespace-nowrap">
                        {log.agentName}
                      </td>
                      <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300 whitespace-nowrap">
                        {log.operation}
                      </td>
                      <td className="py-2.5 px-4 whitespace-nowrap">
                        <span
                          className={
                            log.status === 'success'
                              ? 'text-emerald-600 dark:text-emerald-400 font-medium'
                              : 'text-red-600 dark:text-red-400 font-medium'
                          }
                        >
                          {log.status === 'success' ? 'Completed' : 'Failed'}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200 whitespace-nowrap">
                        {log.tokens.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-600 dark:text-slate-400 whitespace-nowrap">
                        {log.latencyMs.toLocaleString()} ms
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Agent Configuration & Tool Connector Modal */}
      {editingAgent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-xl rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                  {editingAgent.id
                    ? `Configure ${editingAgent.name}`
                    : 'Register New Specialist AI Agent'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Bind Gemini model tier, system persona, GitHub repository target, and webhook integrations.
                </p>
              </div>
              <button
                onClick={() => setEditingAgent(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitAgent} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Agent Name
                  </label>
                  <input
                    type="text"
                    required
                    value={editingAgent.name || ''}
                    onChange={(e) =>
                      setEditingAgent({ ...editingAgent, name: e.target.value })
                    }
                    placeholder="e.g. Prisma Data Engineer"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Specialization / Role
                  </label>
                  <input
                    type="text"
                    required
                    value={editingAgent.role || ''}
                    onChange={(e) =>
                      setEditingAgent({ ...editingAgent, role: e.target.value })
                    }
                    placeholder="e.g. Schema Optimization & SQL"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Server-Side Gemini Model Engine
                </label>
                <select
                  value={editingAgent.model || 'gemini-3.8-flash'}
                  onChange={(e) =>
                    setEditingAgent({
                      ...editingAgent,
                      model: e.target.value as 'gemini-3.8-flash' | 'gemini-3.1-flash-lite',
                    })
                  }
                  className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                >
                  <option value="gemini-3.8-flash">
                    gemini-3.8-flash (Balanced Deep Reasoning & Coding)
                  </option>
                  <option value="gemini-3.1-flash-lite">
                    gemini-3.1-flash-lite (Ultra-Low Latency High Throughput)
                  </option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  System Instructions & Persona Directive
                </label>
                <textarea
                  rows={4}
                  required
                  value={editingAgent.systemInstruction || ''}
                  onChange={(e) =>
                    setEditingAgent({
                      ...editingAgent,
                      systemInstruction: e.target.value,
                    })
                  }
                  placeholder="Define how this agent analyzes inputs, formats code, and collaborates in parallel runs..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Connected GitHub Repository (owner/repo)
                  </label>
                  <input
                    type="text"
                    value={editingAgent.githubRepo || ''}
                    onChange={(e) =>
                      setEditingAgent({
                        ...editingAgent,
                        githubRepo: e.target.value,
                      })
                    }
                    placeholder="e.g. facebook/react"
                    className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Outbound Webhook / Custom Tool Endpoint
                  </label>
                  <input
                    type="url"
                    value={editingAgent.webhookUrl || ''}
                    onChange={(e) =>
                      setEditingAgent({
                        ...editingAgent,
                        webhookUrl: e.target.value,
                      })
                    }
                    placeholder="https://httpbin.org/post"
                    className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Enabled Tool & Pipeline Capabilities
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {AVAILABLE_TOOLS.map((tool) => {
                    const checked = (editingAgent.connectedTools || []).includes(
                      tool.id
                    );
                    return (
                      <button
                        type="button"
                        key={tool.id}
                        onClick={() => handleToggleTool(tool.id)}
                        className={`flex items-center justify-between px-3 py-2 text-xs rounded-lg border text-left transition-colors cursor-pointer ${
                          checked
                            ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200 font-medium'
                            : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                        }`}
                      >
                        <span>{tool.label}</span>
                        {checked && (
                          <Check className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingAgent(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg transition-colors cursor-pointer"
                >
                  {isSaving ? 'Saving Agent...' : 'Save Agent Configuration'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
