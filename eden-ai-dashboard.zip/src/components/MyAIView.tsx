import React, { useState } from 'react';
import type { Agent } from '../types/index.ts';
import {
  Cpu,
  Plus,
  Play,
  Edit3,
  Trash2,
  CheckCircle2,
  GitPullRequest,
  Sparkles,
  Search,
  ExternalLink,
  Code2,
  Box,
  Layers,
  Activity,
  Zap,
} from 'lucide-react';

interface MyAIViewProps {
  agents: Agent[];
  onSaveAgent: (agent: Partial<Agent>) => Promise<void>;
  onDeleteAgent: (id: string) => Promise<void>;
  onSelectAgentForSwarm: (agentId: string) => void;
}

export const MyAIView: React.FC<MyAIViewProps> = ({
  agents,
  onSaveAgent,
  onDeleteAgent,
  onSelectAgentForSwarm,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [selectedAgentForEdit, setSelectedAgentForEdit] = useState<Agent | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [testingAgentId, setTestingAgentId] = useState<string | null>(null);
  const [testSuccessId, setTestSuccessId] = useState<string | null>(null);

  // Form state
  const [formName, setFormName] = useState('');
  const [formRole, setFormRole] = useState('');
  const [formModel, setFormModel] = useState<'gemini-3.8-flash' | 'gemini-3.1-flash-lite'>('gemini-3.8-flash');
  const [formInstruction, setFormInstruction] = useState('');
  const [formColor, setFormColor] = useState('#6366F1');
  const [formWebhook, setFormWebhook] = useState('');
  const [formGithubRepo, setFormGithubRepo] = useState('');
  const [formTools, setFormTools] = useState<string[]>(['artifact_vault']);

  const openDrawer = (agent?: Agent) => {
    if (agent) {
      setSelectedAgentForEdit(agent);
      setFormName(agent.name);
      setFormRole(agent.role);
      setFormModel(agent.model);
      setFormInstruction(agent.systemInstruction);
      setFormColor(agent.color);
      setFormWebhook(agent.webhookUrl || '');
      setFormGithubRepo(agent.githubRepo || '');
      setFormTools(agent.connectedTools || ['artifact_vault']);
    } else {
      setSelectedAgentForEdit(null);
      setFormName('');
      setFormRole('Game Dev & System Specialist');
      setFormModel('gemini-3.8-flash');
      setFormInstruction('You are a dedicated game development AI specialist.');
      setFormColor('#6366F1');
      setFormWebhook('');
      setFormGithubRepo('');
      setFormTools(['artifact_vault']);
    }
    setIsDrawerOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveAgent({
      id: selectedAgentForEdit?.id,
      name: formName,
      role: formRole,
      model: formModel,
      systemInstruction: formInstruction,
      color: formColor,
      webhookUrl: formWebhook,
      githubRepo: formGithubRepo,
      connectedTools: formTools,
    });
    setIsDrawerOpen(false);
  };

  const handleQuickPing = (agentId: string) => {
    setTestingAgentId(agentId);
    setTimeout(() => {
      setTestingAgentId(null);
      setTestSuccessId(agentId);
      setTimeout(() => setTestSuccessId(null), 3000);
    }, 600);
  };

  const getProviderBadge = (agent: Agent) => {
    const text = (agent.name + ' ' + agent.role).toLowerCase();
    if (text.includes('antigravity')) return { label: 'Antigravity Runtime', color: 'text-indigo-400 bg-indigo-500/10' };
    if (text.includes('claude')) return { label: 'Anthropic Claude Bridge', color: 'text-amber-400 bg-amber-500/10' };
    if (text.includes('gpt')) return { label: 'OpenAI GPT-4o Gateway', color: 'text-emerald-400 bg-emerald-500/10' };
    if (text.includes('3d') || text.includes('meshy')) return { label: '3D Mesh Gen (Meshy/Tripo)', color: 'text-pink-400 bg-pink-500/10' };
    if (text.includes('blender')) return { label: 'Blender 4.x Python (bpy)', color: 'text-orange-400 bg-orange-500/10' };
    if (text.includes('ue5') || text.includes('unreal')) return { label: 'Unreal Engine 5 / VS C++', color: 'text-cyan-400 bg-cyan-500/10' };
    if (text.includes('studio')) return { label: 'Google AI Studio Core', color: 'text-blue-400 bg-blue-500/10' };
    return { label: 'Gemini Multimodal Native', color: 'text-purple-400 bg-purple-500/10' };
  };

  const filteredAgents = agents.filter((a) => {
    const matchesSearch =
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.systemInstruction.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (filterCategory === 'all') return true;
    const text = (a.name + ' ' + a.role).toLowerCase();
    if (filterCategory === 'engine') return text.includes('ue5') || text.includes('unreal') || text.includes('blender') || text.includes('claude') || text.includes('antigravity');
    if (filterCategory === '3d') return text.includes('3d') || text.includes('blender') || text.includes('mesh');
    if (filterCategory === 'llm') return text.includes('gemini') || text.includes('gpt') || text.includes('claude') || text.includes('studio');
    return true;
  });

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              My Connected AI & Game Dev Engines
            </h1>
            <span className="px-2 py-0.5 text-xs font-mono font-medium rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
              {agents.length} Connected
            </span>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-3xl">
            Your centralized hub coordinating Antigravity, Google AI Studio, Gemini, Claude, GPT, 3D Modeling AI, Blender bpy automation, and Unreal Engine 5 / Visual Studio pipelines.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => openDrawer()}
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Connect New AI</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-1">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
          {[
            { id: 'all', label: `All Connected (${agents.length})` },
            { id: 'engine', label: 'Game Engines & Code' },
            { id: '3d', label: '3D & Blender Pipelines' },
            { id: 'llm', label: 'Dialogue, Lore & Quests' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterCategory(tab.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                filterCategory === tab.id
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search AI by name, role, or tool..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Connected AI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredAgents.map((agent) => {
          const provider = getProviderBadge(agent);
          const isPinging = testingAgentId === agent.id;
          const isPassed = testSuccessId === agent.id;

          return (
            <div
              key={agent.id}
              className="p-5 rounded-xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 flex flex-col justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-colors shadow-xs"
            >
              <div>
                {/* Agent Lockup */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center text-white shrink-0 font-bold font-mono text-sm shadow-xs"
                      style={{ backgroundColor: agent.color }}
                    >
                      {agent.avatar || agent.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-slate-900 dark:text-white leading-tight">
                        {agent.name}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{agent.role}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => openDrawer(agent)}
                      title="Configure AI model & credentials"
                      className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    {agents.length > 2 && (
                      <button
                        onClick={() => onDeleteAgent(agent.id)}
                        title="Disconnect AI"
                        className="p-1.5 text-slate-400 hover:text-red-500 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Provider Integration Tag (Unboxed Clean) */}
                <div className="mt-3 flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-2xs font-mono font-medium ${provider.color}`}>
                    {provider.label}
                  </span>
                  <span className="text-2xs font-mono text-slate-400">· {agent.model}</span>
                </div>

                {/* System Prompt snippet */}
                <div className="mt-3 text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-950/70 p-3 rounded-lg border border-slate-100 dark:border-slate-800/80 leading-relaxed font-sans line-clamp-3">
                  {agent.systemInstruction}
                </div>

                {/* Integrations & Target Repos */}
                <div className="mt-3 space-y-1.5">
                  {agent.githubRepo && (
                    <div className="flex items-center gap-1.5 text-2xs font-mono text-slate-500 dark:text-slate-400 truncate">
                      <GitPullRequest className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">Repo: {agent.githubRepo}</span>
                    </div>
                  )}
                  {agent.webhookUrl && (
                    <div className="flex items-center gap-1.5 text-2xs font-mono text-slate-500 dark:text-slate-400 truncate">
                      <Cpu className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">Webhook: {agent.webhookUrl}</span>
                    </div>
                  )}
                </div>

                {/* Telemetry numbers (tabular-nums) */}
                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-2xs font-mono text-slate-500 dark:text-slate-400">
                  <span className="tabular-nums">{(agent.totalTokens / 1000).toFixed(1)}k tokens</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">{agent.avgLatencyMs}ms avg</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">{agent.totalRuns} runs</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => handleQuickPing(agent.id)}
                  disabled={isPinging}
                  className="px-2.5 py-1.5 text-2xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors flex items-center gap-1"
                >
                  {isPinging ? (
                    <div className="w-3 h-3 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin" />
                  ) : isPassed ? (
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                  ) : (
                    <Activity className="w-3 h-3 text-slate-400" />
                  )}
                  <span>{isPassed ? 'Ready 100%' : 'Test Bridge'}</span>
                </button>

                <button
                  onClick={() => onSelectAgentForSwarm(agent.id)}
                  className="px-3 py-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 rounded-md transition-colors flex items-center gap-1"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>Command AI</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit or Connect New AI Drawer / Modal */}
      {isDrawerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="w-full max-w-xl rounded-2xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  {selectedAgentForEdit ? `Configure ${selectedAgentForEdit.name}` : 'Connect New AI or Engine Bridge'}
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Configure model architecture, game dev system prompt, tools, and webhook bindings.
                </p>
              </div>
              <button
                onClick={() => setIsDrawerOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm font-semibold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    AI Service / Agent Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Antigravity Build Bot"
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Specialist Role
                  </label>
                  <input
                    type="text"
                    required
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value)}
                    placeholder="e.g. UE5 C++ & Shader Engineering"
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Inference Runtime
                  </label>
                  <select
                    value={formModel}
                    onChange={(e) => setFormModel(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="gemini-3.8-flash">gemini-3.8-flash (Standard & Deep Reasoning)</option>
                    <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Ultra Fast & Low Latency)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Accent Color
                  </label>
                  <div className="flex items-center gap-2 mt-1">
                    {['#6366F1', '#3B82F6', '#8B5CF6', '#D97706', '#10B981', '#EC4899', '#F97316', '#06B6D4'].map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setFormColor(c)}
                        style={{ backgroundColor: c }}
                        className={`w-6 h-6 rounded-full transition-transform ${
                          formColor === c ? 'ring-2 ring-offset-2 ring-indigo-500 scale-110' : 'opacity-80'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  System Instruction / Game Dev Persona
                </label>
                <textarea
                  required
                  rows={4}
                  value={formInstruction}
                  onChange={(e) => setFormInstruction(e.target.value)}
                  placeholder="Define responsibilities, physics principles, shader specifications, or narrative style..."
                  className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Target GitHub Repository (optional)
                  </label>
                  <input
                    type="text"
                    value={formGithubRepo}
                    onChange={(e) => setFormGithubRepo(e.target.value)}
                    placeholder="e.g. EpicGames/UnrealEngine"
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    External API / Webhook URL (optional)
                  </label>
                  <input
                    type="url"
                    value={formWebhook}
                    onChange={(e) => setFormWebhook(e.target.value)}
                    placeholder="https://api.meshy.ai/v2/text-to-3d"
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsDrawerOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm transition-colors"
                >
                  {selectedAgentForEdit ? 'Save Changes' : 'Connect AI'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
