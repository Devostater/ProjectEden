import React, { useState, useMemo, useEffect } from 'react';
import {
  FileCode,
  FolderGit2,
  Plus,
  Download,
  Copy,
  Check,
  Trash2,
  Save,
  Play,
  Search,
  Upload,
  RefreshCw,
} from 'lucide-react';
import type { HostedFile } from '../types';

interface FileVaultViewProps {
  files: HostedFile[];
  selectedFilePath?: string | null;
  onSaveFile: (file: Partial<HostedFile>) => Promise<HostedFile>;
  onDeleteFile: (id: string) => Promise<void>;
  onSyncGitHubRepo: (
    repo: string
  ) => Promise<{ summary: string; importedCount: number }>;
  onAuditFileInSwarm: (fileId: string) => void;
}

export const FileVaultView: React.FC<FileVaultViewProps> = ({
  files,
  selectedFilePath,
  onSaveFile,
  onDeleteFile,
  onSyncGitHubRepo,
  onAuditFileInSwarm,
}) => {
  const [activeFileId, setActiveFileId] = useState<string>(files[0]?.id || '');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [repoInput, setRepoInput] = useState('modelcontextprotocol/servers');
  const [isSyncingRepo, setIsSyncingRepo] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  const [editorContent, setEditorContent] = useState<string>('');
  const [isDirty, setIsDirty] = useState(false);
  const [isSavingFile, setIsSavingFile] = useState(false);
  const [copiedFile, setCopiedFile] = useState(false);

  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [newFilePath, setNewFilePath] = useState('/workspace/agent-spec.md');
  const [newFileContent, setNewFileContent] = useState(
    '# New Hosted Agent Specification\n\nDescribe the workflow, API endpoints, or code module here.\n'
  );

  // Sync active file when selectedFilePath prop changes
  useEffect(() => {
    if (selectedFilePath) {
      const matched = files.find((f) => f.path === selectedFilePath);
      if (matched) {
        setActiveFileId(matched.id);
      }
    }
  }, [selectedFilePath, files]);

  const filteredFiles = useMemo(() => {
    return files.filter((file) => {
      const matchesCategory =
        categoryFilter === 'ALL' || file.category === categoryFilter;
      const matchesSearch =
        !searchQuery.trim() ||
        file.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
        file.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (file.githubRef || '')
          .toLowerCase()
          .includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [files, categoryFilter, searchQuery]);

  const activeFile =
    files.find((f) => f.id === activeFileId) || filteredFiles[0] || files[0];

  useEffect(() => {
    if (activeFile) {
      setEditorContent(activeFile.content);
      setIsDirty(false);
    }
  }, [activeFile?.id]);

  const handleSyncGitHub = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!repoInput.trim() || isSyncingRepo) return;

    setIsSyncingRepo(true);
    setSyncMessage(null);
    try {
      const result = await onSyncGitHubRepo(repoInput.trim());
      setSyncMessage(
        `Synced ${result.importedCount} files from ${repoInput.trim()} into the File Vault.`
      );
      setCategoryFilter('github_repo');
    } catch (err: any) {
      setSyncMessage(
        `GitHub sync notice: ${err?.message || 'Unable to reach repository.'}`
      );
    } finally {
      setIsSyncingRepo(false);
    }
  };

  const handleSaveCurrentFile = async () => {
    if (!activeFile) return;
    setIsSavingFile(true);
    try {
      await onSaveFile({
        id: activeFile.id,
        path: activeFile.path,
        name: activeFile.name,
        content: editorContent,
      });
      setIsDirty(false);
    } finally {
      setIsSavingFile(false);
    }
  };

  const handleCreateNewFile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFilePath.trim()) return;
    setIsSavingFile(true);
    try {
      const created = await onSaveFile({
        path: newFilePath.trim(),
        content: newFileContent,
        category: 'user_upload',
      });
      setActiveFileId(created.id);
      setIsCreatingFile(false);
    } finally {
      setIsSavingFile(false);
    }
  };

  const handleLocalFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploaded = e.target.files?.[0];
    if (!uploaded) return;

    const reader = new FileReader();
    reader.onload = async (ev) => {
      const textContent = String(ev.target?.result || '');
      const created = await onSaveFile({
        path: `/uploads/${uploaded.name}`,
        name: uploaded.name,
        content: textContent,
        category: 'user_upload',
      });
      setActiveFileId(created.id);
    };
    reader.readAsText(uploaded);
  };

  const handleDownloadFile = () => {
    if (!activeFile) return;
    const blob = new Blob([editorContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = activeFile.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleCopyContent = () => {
    navigator.clipboard.writeText(editorContent);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 1800);
  };

  const formatCategoryLabel = (cat: HostedFile['category']) => {
    switch (cat) {
      case 'pipeline_artifact':
        return 'Pipeline Artifact';
      case 'github_repo':
        return 'GitHub Synced';
      case 'agent_scratchpad':
        return 'Agent Config';
      default:
        return 'Hosted File';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <p className="text-xs font-medium text-indigo-600 dark:text-indigo-400 mb-1">
            01. Code & Artifact Hosting Vault + GitHub Sync
          </p>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Files, Artifacts & GitHub Workspace
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
            Browse pipeline-generated deliverables, host project files, pull live repository trees from GitHub, and dispatch files directly to your AI agent swarm.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <label className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer">
            <Upload className="w-3.5 h-3.5" />
            Upload File
            <input
              type="file"
              onChange={handleLocalFileUpload}
              className="hidden"
            />
          </label>

          <button
            onClick={() => setIsCreatingFile(true)}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            New Hosted File
          </button>
        </div>
      </div>

      {/* Live GitHub Repository Connector Bar */}
      <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
              <FolderGit2 className="w-4 h-4 text-slate-800 dark:text-slate-200" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                GitHub Repository Live Ingest & Sync
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Pull repository structure and documentation from any public GitHub repo into your hosted workspace.
              </p>
            </div>
          </div>

          <form
            onSubmit={handleSyncGitHub}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5"
          >
            <input
              type="text"
              value={repoInput}
              onChange={(e) => setRepoInput(e.target.value)}
              placeholder="owner/repo (e.g. facebook/react)"
              className="px-3.5 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 min-w-[260px] focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              disabled={isSyncingRepo}
              className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-white bg-slate-900 dark:bg-slate-100 dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-white rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${isSyncingRepo ? 'animate-spin' : ''}`}
              />
              {isSyncingRepo ? 'Syncing from GitHub...' : 'Sync GitHub Repo'}
            </button>
          </form>
        </div>

        {syncMessage && (
          <p className="text-xs font-mono text-indigo-600 dark:text-indigo-400 pt-1">
            {syncMessage}
          </p>
        )}
      </div>

      {/* Filter Bar & Split-Pane File Explorer + Code Editor */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Segmented Category Filter */}
          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
            {[
              { id: 'ALL', label: `All Files (${files.length})` },
              { id: 'pipeline_artifact', label: 'Pipeline Artifacts' },
              { id: 'github_repo', label: 'GitHub Synced' },
              { id: 'user_upload', label: 'Hosted Code & Uploads' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setCategoryFilter(tab.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  categoryFilter === tab.id
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search file path or GitHub ref..."
              className="pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Pane: File Directory Tree */}
          <div className="lg:col-span-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                Hosted File Tree
              </span>
              <span className="text-xs font-mono tabular-nums text-slate-500">
                {filteredFiles.length} items
              </span>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800/80 max-h-[540px] overflow-y-auto">
              {filteredFiles.map((file) => {
                const isSelected = activeFile?.id === file.id;
                return (
                  <button
                    key={file.id}
                    onClick={() => setActiveFileId(file.id)}
                    className={`w-full text-left p-3.5 transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-50/60 dark:bg-indigo-950/30'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <FileCode
                          className={`w-4 h-4 shrink-0 ${
                            isSelected
                              ? 'text-indigo-600 dark:text-indigo-400'
                              : 'text-slate-400'
                          }`}
                        />
                        <span className="text-xs font-mono font-medium text-slate-900 dark:text-slate-100 truncate">
                          {file.path}
                        </span>
                      </div>
                      <span className="text-[11px] font-mono tabular-nums text-slate-400 shrink-0">
                        {(file.sizeBytes / 1024).toFixed(1)} KB
                      </span>
                    </div>

                    <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      <span>{formatCategoryLabel(file.category)}</span>
                      <span>·</span>
                      <span className="font-mono truncate">
                        {file.githubRef || file.authorAgentName || 'workspace'}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Pane: Code & Artifact Inspector / Editor */}
          <div className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col overflow-hidden">
            {activeFile ? (
              <>
                <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-mono font-semibold text-slate-900 dark:text-slate-100 truncate">
                      {activeFile.path}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {formatCategoryLabel(activeFile.category)} ·{' '}
                      <span className="font-mono tabular-nums">
                        {activeFile.sizeBytes.toLocaleString()} bytes
                      </span>{' '}
                      · Author: {activeFile.authorAgentName || 'Workspace'}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      onClick={() => onAuditFileInSwarm(activeFile.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 rounded-lg hover:bg-indigo-100 transition-colors cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5" />
                      Audit with Swarm
                    </button>

                    <button
                      onClick={handleSaveCurrentFile}
                      disabled={!isDirty || isSavingFile}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 rounded-lg transition-colors cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      {isSavingFile ? 'Saving...' : 'Save Changes'}
                    </button>

                    <button
                      onClick={handleCopyContent}
                      title="Copy Raw File"
                      className="p-1.5 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-lg cursor-pointer"
                    >
                      {copiedFile ? (
                        <Check className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>

                    <button
                      onClick={handleDownloadFile}
                      title="Download File"
                      className="p-1.5 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-lg cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                    </button>

                    {files.length > 1 && (
                      <button
                        onClick={() => onDeleteFile(activeFile.id)}
                        title="Delete File"
                        className="p-1.5 text-slate-400 hover:text-red-600 border border-slate-200 dark:border-slate-800 rounded-lg cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                <textarea
                  value={editorContent}
                  onChange={(e) => {
                    setEditorContent(e.target.value);
                    setIsDirty(true);
                  }}
                  spellCheck={false}
                  className="w-full flex-1 min-h-[460px] p-5 font-mono text-xs leading-relaxed bg-slate-50/50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 focus:outline-none resize-y"
                />
              </>
            ) : (
              <div className="p-12 text-center text-sm text-slate-500">
                Select a hosted file or sync a GitHub repository to inspect its contents.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Create New Hosted File Modal */}
      {isCreatingFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
            <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              Create New Hosted File in Vault
            </h3>
            <form onSubmit={handleCreateNewFile} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Virtual File Path
                </label>
                <input
                  type="text"
                  required
                  value={newFilePath}
                  onChange={(e) => setNewFilePath(e.target.value)}
                  placeholder="/workspace/module.ts"
                  className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Initial Content
                </label>
                <textarea
                  rows={8}
                  required
                  value={newFileContent}
                  onChange={(e) => setNewFileContent(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreatingFile(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingFile}
                  className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg cursor-pointer"
                >
                  Create & Host File
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
