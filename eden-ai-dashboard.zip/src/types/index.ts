export interface Agent {
  id: string;
  name: string;
  role: string;
  avatar: string;
  model: 'gemini-3.8-flash' | 'gemini-3.1-flash-lite';
  systemInstruction: string;
  color: string;
  connectedTools: string[];
  webhookUrl?: string;
  githubRepo?: string;
  totalTokens: number;
  totalRuns: number;
  avgLatencyMs: number;
  status: 'idle' | 'running' | 'offline';
}

export interface SwarmAgentResult {
  agentId: string;
  agentName: string;
  agentRole: string;
  color: string;
  content: string;
  latencyMs: number;
  tokens: number;
  status: 'completed' | 'error';
  error?: string;
}

export interface SwarmRun {
  id: string;
  prompt: string;
  timestamp: string;
  agentIds: string[];
  results: SwarmAgentResult[];
  synthesis?: string;
  savedArtifactPath?: string;
}

export type DAGNodeType = 'agent' | 'github_fetch' | 'api_webhook' | 'artifact_save';

export interface DAGNode {
  id: string;
  label: string;
  type: DAGNodeType;
  agentId?: string;
  prompt?: string;
  repoTarget?: string; // e.g. "owner/repo" or "facebook/react"
  webhookUrl?: string;
  outputPath?: string;
  status: 'idle' | 'running' | 'completed' | 'error';
  lastOutput?: string;
  latencyMs?: number;
  tokens?: number;
  error?: string;
  x: number;
  y: number;
}

export interface DAGEdge {
  id: string;
  source: string;
  target: string;
}

export interface DAGPipeline {
  id: string;
  name: string;
  description: string;
  nodes: DAGNode[];
  edges: DAGEdge[];
  lastRunAt?: string;
  lastStatus?: 'idle' | 'running' | 'completed' | 'error';
}

export interface HostedFile {
  id: string;
  path: string;
  name: string;
  category: 'pipeline_artifact' | 'github_repo' | 'user_upload' | 'agent_scratchpad';
  language: string;
  sizeBytes: number;
  content: string;
  authorAgentName?: string;
  githubRef?: string;
  updatedAt: string;
}

export interface UsageMetric {
  id: string;
  timestamp: string;
  agentId: string;
  agentName: string;
  operation: 'Swarm Broadcast' | 'DAG Step' | 'Consensus Synthesis' | 'Tool Execution';
  tokens: number;
  latencyMs: number;
  status: 'success' | 'error';
}

export interface TelemetrySummary {
  totalTokens: number;
  totalRuns: number;
  avgLatencyMs: number;
  activeAgentsCount: number;
  estimatedCost: number; // calculated at standard rate
  recentLogs: UsageMetric[];
}
