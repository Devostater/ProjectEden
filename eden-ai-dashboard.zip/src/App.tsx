import React, { useState, useEffect } from 'react';
import { Sidebar, type AppTab } from './components/Sidebar.tsx';
import { Header } from './components/Header.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { MyAIView } from './components/MyAIView.tsx';
import { SwarmStudio } from './components/SwarmStudio.tsx';
import { PipelineDAGView } from './components/PipelineDAGView.tsx';
import { FilesVaultView } from './components/FilesVaultView.tsx';
import { BottomOutputDock } from './components/BottomOutputDock.tsx';
import { EdenSanctuaryView } from './components/EdenSanctuaryView.tsx';
import type { Agent, DAGPipeline, HostedFile, TelemetrySummary, SwarmRun } from './types/index.ts';

export default function App() {
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('nexus_theme') === 'light' ? false : true;
  });

  // Default active tab is 'eden' (The simplest tool possible, calm space + data bubbles)
  const [activeTab, setActiveTab] = useState<AppTab>('eden');

  // Application Data State
  const [agents, setAgents] = useState<Agent[]>([]);
  const [pipelines, setPipelines] = useState<DAGPipeline[]>([]);
  const [files, setFiles] = useState<HostedFile[]>([]);
  const [latestSwarmRun, setLatestSwarmRun] = useState<SwarmRun | null>(null);
  const [usageSummary, setUsageSummary] = useState<TelemetrySummary>({
    totalTokens: 203470,
    totalRuns: 180,
    avgLatencyMs: 1072,
    activeAgentsCount: 8,
    estimatedCost: 0.0712,
    recentLogs: [],
  });

  // Cross-view shortcuts
  const [preselectedAgentId, setPreselectedAgentId] = useState<string | undefined>(undefined);

  // Sync dark mode class on document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('nexus_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('nexus_theme', 'light');
    }
  }, [darkMode]);

  // Fetch initial data from full-stack backend
  const refreshAllData = async () => {
    try {
      const workspaceRes = await fetch('/api/workspace');
      if (workspaceRes.ok) {
        const d = await workspaceRes.json();
        if (d.agents) setAgents(d.agents);
        if (d.pipelines) setPipelines(d.pipelines);
        if (d.files) setFiles(d.files);
        if (d.telemetry) setUsageSummary(d.telemetry);
        if (d.swarmRuns && d.swarmRuns.length > 0) {
          setLatestSwarmRun(d.swarmRuns[0]);
        }
        return;
      }

      // Fallback individual routes if needed
      const [agentsRes, usageRes, pipesRes, filesRes] = await Promise.all([
        fetch('/api/agents'),
        fetch('/api/usage'),
        fetch('/api/pipelines'),
        fetch('/api/files'),
      ]);

      if (agentsRes.ok) {
        const d = await agentsRes.json();
        if (d.agents) setAgents(d.agents);
      }
      if (usageRes.ok) {
        const d = await usageRes.json();
        setUsageSummary(d);
      }
      if (pipesRes.ok) {
        const d = await pipesRes.json();
        if (d.pipelines) setPipelines(d.pipelines);
      }
      if (filesRes.ok) {
        const d = await filesRes.json();
        if (d.files) setFiles(d.files);
      }
    } catch (err) {
      console.warn('Initial data load error:', err);
    }
  };

  useEffect(() => {
    refreshAllData();
  }, []);

  // Agent handlers
  const handleSaveAgent = async (agentData: Partial<Agent>) => {
    try {
      const res = await fetch('/api/agents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(agentData),
      });
      if (res.ok) {
        await refreshAllData();
      }
    } catch (err) {
      console.error('Save agent failed:', err);
    }
  };

  const handleDeleteAgent = async (id: string) => {
    try {
      const res = await fetch(`/api/agents/${id}`, { method: 'DELETE' });
      if (res.ok) {
        await refreshAllData();
      }
    } catch (err) {
      console.error('Delete agent failed:', err);
    }
  };

  const handleSelectAgentForSwarm = (agentId: string) => {
    setPreselectedAgentId(agentId);
    setActiveTab('swarm');
  };

  // Pipeline handlers
  const handleSavePipeline = async (pipelineData: DAGPipeline) => {
    try {
      const res = await fetch('/api/pipelines', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pipelineData),
      });
      if (res.ok) {
        await refreshAllData();
      }
    } catch (err) {
      console.error('Save pipeline failed:', err);
    }
  };

  // File handlers
  const handleSaveFile = async (fileData: Partial<HostedFile>) => {
    try {
      const method = fileData.id ? 'PUT' : 'POST';
      const endpoint = fileData.id ? `/api/files/${fileData.id}` : '/api/files';
      const res = await fetch(endpoint, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fileData),
      });
      if (res.ok) {
        await refreshAllData();
      }
    } catch (err) {
      console.error('Save file failed:', err);
    }
  };

  const handleDeleteFile = async (id: string) => {
    try {
      const res = await fetch(`/api/files/${id}`, { method: 'DELETE' });
      if (res.ok) {
        await refreshAllData();
      }
    } catch (err) {
      console.error('Delete file failed:', err);
    }
  };

  const handleSendFileToSwarm = (_file: HostedFile) => {
    setActiveTab('swarm');
  };

  const handleEdenSwarmRun = async (swarmPrompt: string, selectedIds: string[]) => {
    const res = await fetch('/api/swarm/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt: swarmPrompt,
        agentIds: selectedIds,
        contextFileIds: [],
      }),
    });
    if (!res.ok) throw new Error('Swarm run failed');
    const data = await res.json();
    await refreshAllData();
    return data;
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors">
      {/* 1. Left Side Scrolling Tabs Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        agents={agents}
        pipelines={pipelines}
        files={files}
        totalTokens={usageSummary.totalTokens}
      />

      {/* 2. Main Interface to the Right */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden relative">
        {/* Topbar with preserved action buttons */}
        <Header
          activeTab={activeTab}
          onQuickRun={() => setActiveTab('swarm')}
          onDeployAI={() => setActiveTab('my-ai')}
          darkMode={darkMode}
          setDarkMode={setDarkMode}
          totalTokens={usageSummary.totalTokens}
          agentCount={agents.length}
        />

        {/* Scrollable Main Viewport (with padding for bottom output dock) */}
        <main className="flex-1 overflow-y-auto pb-48 sm:pb-56">
          {activeTab === 'eden' && (
            <EdenSanctuaryView
              agents={agents}
              files={files}
              usageSummary={usageSummary}
              onExecuteSwarm={handleEdenSwarmRun}
              onOpenInVault={(_path) => setActiveTab('files')}
              onSwitchToConsole={() => setActiveTab('dashboard')}
            />
          )}

          {activeTab === 'dashboard' && (
            <DashboardView
              agents={agents}
              usageSummary={usageSummary}
              onNavigateToAI={() => setActiveTab('my-ai')}
              onNavigateToSwarm={() => setActiveTab('swarm')}
            />
          )}

          {activeTab === 'my-ai' && (
            <MyAIView
              agents={agents}
              onSaveAgent={handleSaveAgent}
              onDeleteAgent={handleDeleteAgent}
              onSelectAgentForSwarm={handleSelectAgentForSwarm}
            />
          )}

          {activeTab === 'swarm' && (
            <SwarmStudio
              agents={agents}
              files={files}
              preselectedAgentId={preselectedAgentId}
              onSaveToVault={handleSaveFile}
              onExecutionComplete={refreshAllData}
            />
          )}

          {activeTab === 'pipelines' && (
            <PipelineDAGView
              pipelines={pipelines}
              agents={agents}
              onSavePipeline={handleSavePipeline}
              onRefreshData={refreshAllData}
            />
          )}

          {activeTab === 'files' && (
            <FilesVaultView
              files={files}
              onSaveFile={handleSaveFile}
              onDeleteFile={handleDeleteFile}
              onSendFileToSwarm={handleSendFileToSwarm}
            />
          )}
        </main>

        {/* 3. Output as a Bottom Dock (Collapsible, expandable, console streams) */}
        <BottomOutputDock
          latestSwarmRun={latestSwarmRun}
          recentLogs={usageSummary.recentLogs}
          activePipelineOutput={
            pipelines[0] && pipelines[0].nodes[0]
              ? { name: pipelines[0].name, output: pipelines[0].nodes[0].lastOutput || '' }
              : null
          }
          onOpenInVault={(_path) => setActiveTab('files')}
        />
      </div>
    </div>
  );
}
